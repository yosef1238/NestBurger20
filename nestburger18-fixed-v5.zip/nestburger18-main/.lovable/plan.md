## Goal
Turn `/nest-crew` into a production SaaS admin: roles (owner/admin/staff), every image swappable, every homepage section editable, real-time updates. Keep existing data (`site_settings`, `trending_items`, `menu_items`); add the new layers on top.

## 1. Backend (extends current schema)

New / updated tables:

- `profiles` — `id (= auth.uid)`, `email`, `full_name`, `role` (`owner|admin|staff`), `can_manage_users`. Auto-created on signup via trigger.
- `app_role` enum: add `owner`, `staff` (already has `admin`). `user_roles` stays as the source of truth for `has_role()`; `profiles.role` mirrors it for UI.
- `heavy_hitters` — `id, title, price, description, image_url, order_index, visible`. Public site reads this in addition to existing `trending_items`.
- `image_registry` — `id, location_key (unique, e.g. "homepage.hero", "menu.section.bg"), url, alt, description, updated_by, updated_at`.
- `gallery_images` — `id, section (e.g. "homepage.hero_slider", "heavy_hitters.slider"), image_url, order_index, visible`. Powers all sliders.
- `homepage_sections` — `id, key (unique, e.g. "hero", "about", "contact"), title, subtitle, body, extra (jsonb), visible, order_index`. Powers all editable text/layout.

RLS:
- Public `SELECT` on content tables (`menu_items`, `trending_items`, `heavy_hitters`, `image_registry`, `gallery_images`, `homepage_sections`, `site_settings`).
- Write on content tables: `has_role(uid,'owner') OR has_role(uid,'admin') OR has_role(uid,'staff')` (staff limited to update-only on a whitelist of tables; no DELETE).
- `profiles`/`user_roles`: read own + owners read all; only owners write.
- Add `service_role` GRANTs on every new table.

Storage:
- Reuse `nest-media` bucket. Add storage RLS: authenticated crew can `INSERT/UPDATE/DELETE`; everyone can `SELECT`.

Seeding:
- Seed `image_registry` with every image key the current site uses (hero bg, logo, about, contact, footer, each menu/trending card fallback).
- Seed `homepage_sections` with current hero/about/contact text.
- Owner: grant `owner` role to `yoom15422@gmail.com` (creates profile + user_roles row if missing; if the auth user doesn't exist yet, a pending-owner row + post-signup trigger promotes them on first login).

## 2. Frontend — public site

- New `useImage(locationKey, fallback)` hook → reads `image_registry` via TanStack Query, subscribes to realtime so swaps appear with no refresh.
- New `useSection(key)` hook for `homepage_sections` text.
- New `useSlider(section)` hook for `gallery_images`.
- Replace every hardcoded `<img>`/`background-image` in `Hero`, `Navbar`, `Footer`, `Contact`, `Trending`, `MenuSection`, `FloatingOrder` with `useImage(...)`.
- Keep Trending as-is (still editable). Add a new **Heavy Hitters** section below it:
  - 1–3 items → static grid.
  - 4+ items → embla slider with arrows + optional autoplay.
- All sliders use `embla-carousel-react` (already installed via shadcn carousel).

## 3. Admin dashboard `/nest-crew`

SaaS shell with shadcn `Sidebar` + top navbar, dark mode toggle, framer-motion page transitions, mobile responsive.

Routes (all under `_authenticated/nest-crew/*`, gated by `requireRole`):
- `/nest-crew` → **Overview** (counts, recent edits, who's online).
- `/nest-crew/menu` → Menu CRUD, grouped by category, image upload, drag-reorder.
- `/nest-crew/heavy-hitters` → CRUD + reorder + image upload.
- `/nest-crew/trending` → existing Trending CRUD (kept).
- `/nest-crew/gallery` → per-section slider manager (add/remove/reorder images).
- `/nest-crew/homepage` → edit `homepage_sections` (title/subtitle/body/extra).
- `/nest-crew/images` → **Global Image Editor**: visual grid of every `location_key`, click → upload replacement, instant propagation.
- `/nest-crew/settings` → WhatsApp / Instagram / Facebook / hero pills (existing `site_settings`).
- `/nest-crew/users` (owner only) → invite by email, assign role, toggle `can_manage_users`, remove.
- `/nest-crew/login` → email+password sign-in (no public signup).

Permissions in UI:
- owner: everything + Users.
- admin: everything except Users.
- staff: Menu, Heavy Hitters, Trending, Gallery, Images — update only, no delete, no settings.

## 4. Real-time

One realtime channel per page subscribing to `postgres_changes` on the relevant table → `queryClient.invalidateQueries` on the matching key. Public site subscribes to `image_registry`, `homepage_sections`, `gallery_images`, `heavy_hitters`, `menu_items`, `trending_items`.

## 5. Server functions (TanStack `createServerFn`)

- `inviteUser({ email, role, can_manage_users })` — owner only; uses `supabaseAdmin` to create auth user + profile + user_roles, sends magic-link email.
- `updateUserRole`, `removeUser` — owner only.
- `claimFirstOwner` — replaces current `claimFirstAdmin`; assigns `owner` if no owner exists.
- `uploadImage(locationKey, file)` — handled via browser Supabase client straight to storage; server fn just updates `image_registry`.

All writes go through fns with `requireSupabaseAuth` + role check; staff-allowed fns enforce the whitelist.

## 6. Design

Keep current brand (warm/dark frosted). Dashboard side adopts a clean SaaS look: neutral surface tokens (`--surface`, `--surface-2`), accent stays the brand orange, sidebar collapses to icon strip, framer-motion fades on route change, sonner toasts for every action.

## Tech notes

- Heavy lifts split into small `*.functions.ts` files under `src/lib/admin/`.
- `useImage` reads from a single in-memory map keyed by `location_key`; one query fetches the whole registry to keep it cheap.
- `embla-carousel-autoplay` added for slider autoplay.
- Migrations run in this order: enum extension → profiles + trigger → heavy_hitters → image_registry → gallery_images → homepage_sections → storage RLS → seeds → owner grant.
- After migration approval I regenerate code, install `embla-carousel-autoplay` + `@fontsource` for the dashboard font, then ship the dashboard, public-site rewrites, and realtime wiring.

## Out of scope (will note as next steps)
- Audit log table.
- Multi-language content.
- Per-item analytics.
