import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { FeaturedBurgers } from "@/components/site/FeaturedBurgers";
import { MenuSection } from "@/components/site/MenuSection";
import { Trending } from "@/components/site/Trending";
import { HeavyHitters } from "@/components/site/HeavyHitters";
import { About } from "@/components/site/About";
import { Offers } from "@/components/site/Offers";
import { Reviews } from "@/components/site/Reviews";
import { Gallery } from "@/components/site/Gallery";
import { Locations } from "@/components/site/Locations";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";
import { FloatingOrder } from "@/components/site/FloatingOrder";
import { SmoothScroll } from "@/components/site/SmoothScroll";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nest Burger — Crafted for Real Burger Lovers" },
      { name: "description", content: "Premium hand-pressed burgers, crispy chicken, loaded fries and the legendary Nest sauce. Order now on WhatsApp." },
      { property: "og:title", content: "Nest Burger — The Real Original Taste" },
      { property: "og:description", content: "Hand-pressed beef, crispy chicken, signature Nest sauce. Order now on WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative bg-background text-foreground">
      <SmoothScroll />
      <Navbar />
      <Hero />
      <FeaturedBurgers />
      <Trending />
      <HeavyHitters />
      <MenuSection />
      <About />
      <Offers />
      <Reviews />
      <Gallery />
      <Locations />
      <Contact />
      <Footer />
      <FloatingOrder />
    </main>
  );
}
