import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ChevronDown,
  ChevronUp,
  Eye,
  EyeOff,
  ImagePlus,
  Loader2,
  LogOut,
  Plus,
  Save,
  Trash2,
  X,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { claimFirstOwner } from "@/lib/crew.functions";
import { HeavyHittersAdmin } from "@/components/admin/HeavyHittersAdmin";
import { ImageRegistryAdmin } from "@/components/admin/ImageRegistryAdmin";
import { GalleryAdmin } from "@/components/admin/GalleryAdmin";
import { HomepageSectionsAdmin } from "@/components/admin/HomepageSectionsAdmin";
import { UsersAdmin } from "@/components/admin/UsersAdmin";
import { useCrewProfile } from "@/lib/cms";

export const Route = createFileRoute("/nest-crew")({
  ssr: false,
  head: () => ({ meta: [{ title: "Nest Crew", name: "robots", content: "noindex,nofollow" }] }),
  component: NestCrewPage,
});

function NestCrewPage() {
  const [session, setSession] = useState<any | null | undefined>(undefined);
  const [isAdmin, setIsAdmin] = useState<boolean | undefined>(undefined);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (mounted) setSession(data.session);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!session?.user) {
      setIsAdmin(undefined);
      return;
    }
    supabase
      .from("user_roles")
      .select("id, role")
      .eq("user_id", session.user.id)
      .in("role", ["owner", "admin", "staff"])
      .then(({ data, error }) => {
        // [NB-012] Previously had no error handling — a failed query silently
        // resolved isAdmin to false with zero feedback. Now logged loudly.
        if (error) {
          console.error("[NB-012] user_roles check failed:", error.code, error.message);
        }
        setIsAdmin(!!(data && data.length));
      });
  }, [session?.user?.id]);

  if (session === undefined) {
    return (
      <div className="min-h-screen grid place-items-center bg-background text-foreground">
        <Loader2 className="h-6 w-6 animate-spin text-[var(--gold)]" />
      </div>
    );
  }

  if (!session) return <AuthScreen />;
  if (isAdmin === undefined) {
    return (
      <div className="min-h-screen grid place-items-center bg-background text-foreground">
        <Loader2 className="h-6 w-6 animate-spin text-[var(--gold)]" />
      </div>
    );
  }
  if (!isAdmin) return <ClaimOrDenyScreen email={session.user.email} />;

  return <Dashboard userId={session.user.id} email={session.user.email} />;
}

/* ----------------------- AUTH ----------------------- */

function AuthScreen() {
  // Signup is intentionally disabled on this screen.
  // New crew members are invited by the owner via the Users tab.
  // This screen is sign-in only to prevent unauthorized account creation.
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        // [NB-015] Sign-in rejected by Supabase Auth — wrong password, unconfirmed
        // email, or rate-limited. Previously invisible with no Toaster mounted.
        console.error("[NB-015] signInWithPassword failed:", error.status, error.message);
        throw error;
      }
      toast.success("Welcome back, crew.");
    } catch (err: any) {
      toast.error(err.message ?? "[NB-015] Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen grid place-items-center bg-background text-foreground px-4">
      <div className="w-full max-w-sm rounded-3xl frost border border-white/10 p-8">
        <div className="text-center mb-6">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[var(--gold)] text-[var(--primary-foreground)] font-display text-2xl">
            N
          </div>
          <h1 className="font-display text-3xl mt-3">NEST CREW</h1>
          <p className="text-sm text-foreground/60 mt-1">Crew access only. Contact your owner to get an invite.</p>
        </div>

        <form onSubmit={submit} className="space-y-3">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" disabled={busy} className="w-full bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign in"}
          </Button>
        </form>
      </div>
    </div>
  );
}

function ClaimOrDenyScreen({ email }: { email?: string }) {
  const [busy, setBusy] = useState(false);
  const [denied, setDenied] = useState(false);
  const claim = useServerFn(claimFirstOwner);

  async function tryClaim() {
    setBusy(true);
    try {
      const res = await claim();
      if (res.ok) {
        toast.success("You're now the owner.");
        window.location.reload();
      } else {
        // [NB-013] No owner-claim path matched — surfaced now that Toaster is mounted.
        console.warn("[NB-013] claimFirstOwner denied:", res.reason);
        setDenied(true);
      }
    } catch (e: any) {
      // [NB-014] claimFirstOwner threw — usually an auth-middleware rejection
      // (expired session, missing token) or a DB write failure.
      console.error("[NB-014] claimFirstOwner failed:", e.message);
      toast.error(e.message ?? "[NB-014] Failed to claim owner access");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen grid place-items-center bg-background text-foreground px-4">
      <div className="w-full max-w-md rounded-3xl frost border border-white/10 p-8 text-center">
        <h1 className="font-display text-3xl">{denied ? "Not authorized" : "Activate owner account"}</h1>
        <p className="text-sm text-foreground/60 mt-2">
          Signed in as <span className="text-[var(--gold)]">{email}</span>
        </p>
        {!denied ? (
          <>
            <p className="mt-4 text-sm text-foreground/70">
              If you're the first owner setting this up, tap below to claim owner access.
            </p>
            <Button onClick={tryClaim} disabled={busy} className="mt-5 bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Claim owner access"}
            </Button>
          </>
        ) : (
          <p className="mt-4 text-sm text-foreground/70">
            An owner already exists. Ask them to grant you access.
          </p>
        )}
        <button
          onClick={() => supabase.auth.signOut()}
          className="mt-6 text-xs text-foreground/60 hover:text-[var(--gold)] inline-flex items-center gap-1"
        >
          <LogOut className="h-3 w-3" /> Sign out
        </button>
      </div>
    </div>
  );
}

/* ----------------------- DASHBOARD ----------------------- */

function Dashboard({ userId, email }: { userId: string; email?: string }) {
  const { data: profile } = useCrewProfile(userId);
  const isOwner = profile?.role === "owner";
  const canManage = isOwner || (profile?.role === "admin" && profile?.can_manage_users);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-white/10 bg-background/80 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-[var(--gold)] text-[var(--primary-foreground)] font-display text-lg">N</div>
            <div>
              <div className="font-display text-lg leading-none">NEST CREW</div>
              <div className="text-[11px] text-foreground/60 mt-0.5 flex items-center gap-1.5">
                <span>{email}</span>
                {profile?.role && (
                  <span className="rounded-full px-1.5 py-0.5 text-[9px] font-bold tracking-wider bg-[var(--gold)]/20 text-[var(--gold)] uppercase">
                    {profile.role}
                  </span>
                )}
              </div>
            </div>
          </div>
          <Button variant="ghost" onClick={() => supabase.auth.signOut()}>
            <LogOut className="h-4 w-4 mr-2" /> Sign out
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <Tabs defaultValue="heavy">
          <TabsList className="flex flex-wrap h-auto">
            <TabsTrigger value="heavy">Heavy Hitters</TabsTrigger>
            <TabsTrigger value="trending">Trending</TabsTrigger>
            <TabsTrigger value="menu">Menu</TabsTrigger>
            <TabsTrigger value="images">Images</TabsTrigger>
            <TabsTrigger value="gallery">Galleries</TabsTrigger>
            <TabsTrigger value="homepage">Homepage</TabsTrigger>
            <TabsTrigger value="pills">Hero Pills</TabsTrigger>
            <TabsTrigger value="links">Links</TabsTrigger>
            {canManage && <TabsTrigger value="users">Users</TabsTrigger>}
          </TabsList>

          <TabsContent value="heavy" className="mt-6"><HeavyHittersAdmin /></TabsContent>
          <TabsContent value="trending" className="mt-6"><ItemsAdmin table="trending_items" kind="trending" /></TabsContent>
          <TabsContent value="menu" className="mt-6"><ItemsAdmin table="menu_items" kind="menu" /></TabsContent>
          <TabsContent value="images" className="mt-6"><ImageRegistryAdmin /></TabsContent>
          <TabsContent value="gallery" className="mt-6"><GalleryAdmin /></TabsContent>
          <TabsContent value="homepage" className="mt-6"><HomepageSectionsAdmin /></TabsContent>
          <TabsContent value="pills" className="mt-6"><PillsAdmin /></TabsContent>
          <TabsContent value="links" className="mt-6"><LinksAdmin /></TabsContent>
          {canManage && <TabsContent value="users" className="mt-6"><UsersAdmin currentUserId={userId} /></TabsContent>}
        </Tabs>
      </main>
    </div>
  );
}

/* ----------------------- ITEMS (trending + menu) ----------------------- */

type Row = {
  id: string;
  name: string;
  description: string;
  price: string;
  image_url: string | null;
  sort_order: number;
  visible: boolean;
  // trending only
  tag?: string;
  emoji?: string;
  // menu only
  category?: string;
};

function ItemsAdmin({ table, kind }: { table: "trending_items" | "menu_items"; kind: "trending" | "menu" }) {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: [table, "admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from(table).select("*").order("sort_order");
      if (error) throw error;
      return data as Row[];
    },
  });

  const grouped = useMemo(() => {
    if (kind !== "menu" || !data) return null;
    const g: Record<string, Row[]> = {};
    for (const r of data) {
      const c = r.category || "uncategorized";
      (g[c] ||= []).push(r);
    }
    return g;
  }, [data, kind]);

  async function refresh() {
    await qc.invalidateQueries({ queryKey: [table] });
  }

  async function addRow() {
    const sort = (data?.length ?? 0) + 1;
    const payload: any =
      kind === "trending"
        ? { name: "New item", description: "", price: "0", tag: "", emoji: "🔥", sort_order: sort, visible: true }
        : { name: "New item", category: "beef", description: "", price: "0", sort_order: sort, visible: true };
    const { error } = await supabase.from(table).insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Added");
    refresh();
  }

  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" />;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="font-display text-2xl">{kind === "trending" ? "Trending Items" : "Menu Items"}</h2>
        <Button onClick={addRow} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
          <Plus className="h-4 w-4 mr-1" /> Add
        </Button>
      </div>

      {kind === "trending" && (
        <div className="grid gap-3">
          {data?.map((row, i) => (
            <ItemCard key={row.id} table={table} kind={kind} row={row} index={i} total={data.length} onChange={refresh} />
          ))}
        </div>
      )}

      {kind === "menu" && grouped && (
        <div className="space-y-6">
          {Object.entries(grouped).map(([cat, rows]) => (
            <div key={cat}>
              <div className="text-xs font-bold tracking-widest text-[var(--gold)] uppercase mb-2">{cat}</div>
              <div className="grid gap-3">
                {rows.map((row, i) => (
                  <ItemCard key={row.id} table={table} kind={kind} row={row} index={i} total={rows.length} onChange={refresh} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ItemCard({
  table,
  kind,
  row,
  index,
  total,
  onChange,
}: {
  table: "trending_items" | "menu_items";
  kind: "trending" | "menu";
  row: Row;
  index: number;
  total: number;
  onChange: () => void;
}) {
  const [local, setLocal] = useState<Row>(row);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const dirty = JSON.stringify(local) !== JSON.stringify(row);

  useEffect(() => setLocal(row), [row.id]);

  async function save() {
    setSaving(true);
    const { id, ...patch } = local;
    const { error } = await (supabase.from(table) as any).update(patch).eq("id", id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    onChange();
  }

  async function remove() {
    if (!confirm(`Delete "${row.name}"?`)) return;
    const { error } = await supabase.from(table).delete().eq("id", row.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    onChange();
  }

  async function toggleVisible() {
    const { error } = await supabase.from(table).update({ visible: !row.visible }).eq("id", row.id);
    if (error) return toast.error(error.message);
    onChange();
  }

  async function move(dir: -1 | 1) {
    const newOrder = row.sort_order + dir;
    const { error } = await supabase.from(table).update({ sort_order: newOrder }).eq("id", row.id);
    if (error) return toast.error(error.message);
    onChange();
  }

  async function upload(file: File) {
    setUploading(true);
    try {
      // Validate MIME type — reject anything that isn't a real image.
      const ALLOWED = new Set(["image/jpeg","image/png","image/webp","image/gif","image/avif"]);
      const MIME_EXT: Record<string,string> = { "image/jpeg":"jpg","image/png":"png","image/webp":"webp","image/gif":"gif","image/avif":"avif" };
      if (!ALLOWED.has(file.type)) throw new Error(`File type "${file.type}" not allowed. Use JPEG, PNG, WebP, GIF or AVIF.`);
      const ext = MIME_EXT[file.type] ?? "jpg";
      const path = `${table}/${row.id}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("nest-media").upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw upErr;
      const { data } = supabase.storage.from("nest-media").getPublicUrl(path);
      const url = data.publicUrl;
      const { error } = await supabase.from(table).update({ image_url: url }).eq("id", row.id);
      if (error) throw error;
      toast.success("Photo uploaded");
      onChange();
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="rounded-2xl frost border border-white/10 p-4">
      <div className="flex flex-col md:flex-row gap-4">
        <label className="relative shrink-0 grid h-24 w-24 place-items-center rounded-xl bg-black/40 border border-white/10 overflow-hidden cursor-pointer hover:border-[var(--gold)]/40">
          {row.image_url ? (
            <img src={row.image_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <ImagePlus className="h-5 w-5 text-foreground/40" />
          )}
          {uploading && <div className="absolute inset-0 grid place-items-center bg-black/50"><Loader2 className="h-5 w-5 animate-spin" /></div>}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) upload(f);
            }}
          />
        </label>

        <div className="flex-1 grid gap-2 md:grid-cols-2">
          {kind === "menu" && (
            <Input value={local.category ?? ""} placeholder="category" onChange={(e) => setLocal({ ...local, category: e.target.value })} />
          )}
          <Input value={local.name} placeholder="Name" onChange={(e) => setLocal({ ...local, name: e.target.value })} />
          <Input value={local.price} placeholder="Price" onChange={(e) => setLocal({ ...local, price: e.target.value })} />
          {kind === "trending" && (
            <>
              <Input value={local.emoji ?? ""} placeholder="Emoji" maxLength={4} onChange={(e) => setLocal({ ...local, emoji: e.target.value })} />
              <Input value={local.tag ?? ""} placeholder="Tag (e.g. Bestseller)" onChange={(e) => setLocal({ ...local, tag: e.target.value })} />
            </>
          )}
          <Textarea
            value={local.description}
            placeholder="Description"
            className="md:col-span-2"
            rows={2}
            onChange={(e) => setLocal({ ...local, description: e.target.value })}
          />
        </div>

        <div className="flex md:flex-col gap-1 justify-end">
          <Button variant="ghost" size="icon" disabled={index === 0} onClick={() => move(-1)}><ChevronUp className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" disabled={index === total - 1} onClick={() => move(1)}><ChevronDown className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" onClick={toggleVisible} title={row.visible ? "Hide" : "Show"}>
            {row.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4 text-foreground/40" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={remove}><Trash2 className="h-4 w-4 text-red-400" /></Button>
        </div>
      </div>

      {dirty && (
        <div className="mt-3 flex justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={() => setLocal(row)}><X className="h-3 w-3 mr-1" /> Cancel</Button>
          <Button size="sm" onClick={save} disabled={saving} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="h-3 w-3 mr-1" /> Save</>}
          </Button>
        </div>
      )}
    </div>
  );
}

/* ----------------------- PILLS ----------------------- */

function PillsAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["site_settings", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).single();
      if (error) throw error;
      return data;
    },
  });
  const [pills, setPills] = useState<string[]>([]);
  useEffect(() => {
    if (data) setPills(Array.isArray((data as any).hero_pills) ? ((data as any).hero_pills as string[]) : []);
  }, [data]);

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("site_settings").update({ hero_pills: pills }).eq("id", 1);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Hero pills updated");
      qc.invalidateQueries({ queryKey: ["site_settings"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" />;

  return (
    <div className="max-w-xl space-y-4">
      <div>
        <h2 className="font-display text-2xl">Hero Pills</h2>
        <p className="text-sm text-foreground/60 mt-1">
          Small floating tags on the hero (e.g. "FRESH DAILY"). They render in pixel font.
        </p>
      </div>
      <div className="space-y-2">
        {pills.map((p, i) => (
          <div key={i} className="flex gap-2">
            <Input value={p} onChange={(e) => setPills(pills.map((x, j) => (j === i ? e.target.value : x)))} />
            <Button variant="ghost" size="icon" onClick={() => setPills(pills.filter((_, j) => j !== i))}>
              <Trash2 className="h-4 w-4 text-red-400" />
            </Button>
          </div>
        ))}
        <Button variant="ghost" onClick={() => setPills([...pills, "NEW PILL"])}>
          <Plus className="h-4 w-4 mr-1" /> Add pill
        </Button>
      </div>
      <Button onClick={() => save.mutate()} disabled={save.isPending} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
        {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Save className="h-4 w-4 mr-1" /> Save</>}
      </Button>
    </div>
  );
}

/* ----------------------- LINKS ----------------------- */

function LinksAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["site_settings", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).single();
      if (error) throw error;
      return data;
    },
  });
  const [form, setForm] = useState({ whatsapp_number: "", instagram_url: "", facebook_url: "" });
  useEffect(() => {
    if (data) setForm({
      whatsapp_number: (data as any).whatsapp_number ?? "",
      instagram_url: (data as any).instagram_url ?? "",
      facebook_url: (data as any).facebook_url ?? "",
    });
  }, [data]);

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("site_settings").update(form).eq("id", 1);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Links updated");
      qc.invalidateQueries({ queryKey: ["site_settings"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" />;

  return (
    <div className="max-w-xl space-y-4">
      <h2 className="font-display text-2xl">Contact Links</h2>
      <div>
        <Label>WhatsApp number (digits only, with country code)</Label>
        <Input value={form.whatsapp_number} onChange={(e) => setForm({ ...form, whatsapp_number: e.target.value })} placeholder="201006973278" />
      </div>
      <div>
        <Label>Instagram URL</Label>
        <Input value={form.instagram_url} onChange={(e) => setForm({ ...form, instagram_url: e.target.value })} placeholder="https://instagram.com/..." />
      </div>
      <div>
        <Label>Facebook URL</Label>
        <Input value={form.facebook_url} onChange={(e) => setForm({ ...form, facebook_url: e.target.value })} placeholder="https://facebook.com/..." />
      </div>
      <Button onClick={() => save.mutate()} disabled={save.isPending} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
        {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Save className="h-4 w-4 mr-1" /> Save</>}
      </Button>
    </div>
  );
}
