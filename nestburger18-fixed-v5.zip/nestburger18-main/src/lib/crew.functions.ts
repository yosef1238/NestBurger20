import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Role = "owner" | "admin" | "staff";

async function assertOwner(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .eq("role", "owner")
    .maybeSingle();
  if (!data) throw new Error("Forbidden: owner only");
}

/** Owner only. Invites/creates a crew user and assigns role. */
export const inviteCrewUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (d: { email: string; role: Role; can_manage_users: boolean; full_name?: string }) => d,
  )
  .handler(async ({ data, context }) => {
    await assertOwner(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const email = data.email.trim().toLowerCase();

    // Does user exist?
    const { data: existing } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    let userId: string | null = (existing as any)?.id ?? null;

    if (!userId) {
      // Try invite (sends email if SMTP configured)
      const inv = await supabaseAdmin.auth.admin.inviteUserByEmail(email);
      if (inv.error) {
        // Fall back to direct create
        const created = await supabaseAdmin.auth.admin.createUser({
          email,
          email_confirm: true,
          user_metadata: { full_name: data.full_name ?? "" },
        });
        if (created.error) throw created.error;
        userId = created.data.user?.id ?? null;
      } else {
        userId = inv.data.user?.id ?? null;
      }
    }
    if (!userId) throw new Error("Could not create user");

    await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: userId, role: data.role }, { onConflict: "user_id,role" });

    await supabaseAdmin
      .from("profiles")
      .upsert(
        {
          id: userId,
          email,
          role: data.role,
          can_manage_users: data.can_manage_users,
          full_name: data.full_name ?? "",
        },
        { onConflict: "id" },
      );

    return { ok: true, userId };
  });

export const updateCrewUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; role: Role; can_manage_users: boolean }) => d)
  .handler(async ({ data, context }) => {
    await assertOwner(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Replace user_roles entries with the new single role
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.id);
    await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: data.id, role: data.role });

    await supabaseAdmin
      .from("profiles")
      .update({ role: data.role, can_manage_users: data.can_manage_users })
      .eq("id", data.id);

    return { ok: true };
  });

export const removeCrewUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data, context }) => {
    await assertOwner(context.userId);
    if (data.id === context.userId) throw new Error("Cannot remove yourself");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.id);
    if (error) throw error;
    return { ok: true };
  });

/** Bootstrap: first signed-in user with no owner yet becomes owner. */
export const claimFirstOwner = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count } = await supabaseAdmin
      .from("user_roles")
      .select("*", { count: "exact", head: true })
      .eq("role", "owner");
    if ((count ?? 0) > 0) return { ok: false as const, reason: "An owner already exists." };
    await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: context.userId, role: "owner" });
    await supabaseAdmin
      .from("profiles")
      .update({ role: "owner", can_manage_users: true })
      .eq("id", context.userId);
    return { ok: true as const };
  });
