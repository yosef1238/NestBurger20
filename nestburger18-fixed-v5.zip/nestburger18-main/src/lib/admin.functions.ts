import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * claimFirstAdmin has been intentionally REMOVED as a security fix.
 *
 * It allowed any authenticated user to grant themselves the `admin` role
 * simply by being the first caller, making it a self-escalation vector.
 *
 * Role assignment is now exclusively handled by `crew.functions.ts`:
 *   - `claimFirstOwner`  — owner bootstrap (still protected by supabaseAdmin)
 *   - `inviteCrewUser`   — owner-only role assignment for other users
 *   - `updateCrewUser`   — owner-only role update
 *
 * The `user_roles` table now has write access revoked from `authenticated`
 * at the database level (see security_fixes migration), so even if this
 * function were re-introduced it could not write directly.
 */
