import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// ─── Realtime is intentionally REMOVED from all public-facing hooks ───────────
// Reason: postgres_changes subscriptions throw unhandled errors when the table
// doesn't exist or Realtime isn't enabled, crashing the entire React tree
// (NB-RT-* errors). Public pages use refetchInterval polling instead —
// good enough for a restaurant site and zero crash risk.
// Realtime can be re-enabled per-table once confirmed working in Supabase dashboard.
// ─────────────────────────────────────────────────────────────────────────────

/* ============================================================
   Image Registry
   ============================================================ */

export type ImageRow = {
  id: string;
  location_key: string;
  url: string;
  alt: string;
  description: string;
};

const REGISTRY_KEY = ["image_registry"] as const;

export function useImageRegistry() {
  return useQuery({
    queryKey: REGISTRY_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("image_registry" as any)
        .select("id, location_key, url, alt, description");
      if (error) {
        console.error("[NB-002] image_registry query failed:", error.code, error.message);
        return { rows: [] as ImageRow[], map: new Map<string, ImageRow>() };
      }
      const rows = ((data ?? []) as unknown) as ImageRow[];
      const map = new Map<string, ImageRow>();
      rows.forEach((r) => map.set(r.location_key, r));
      return { rows, map };
    },
    staleTime: 60_000,
    refetchInterval: 120_000, // poll every 2 min instead of realtime
    retry: false,             // don't retry on error — fall back immediately
  });
}

export function useImage(locationKey: string, fallback?: string): string | undefined {
  const { data } = useImageRegistry();
  return data?.map.get(locationKey)?.url || fallback;
}

/* ============================================================
   Homepage Sections
   ============================================================ */

export type SectionRow = {
  id: string;
  section_key: string;
  title: string;
  subtitle: string;
  body: string;
  extra: Record<string, any>;
  visible: boolean;
  order_index: number;
};

const SECTIONS_KEY = ["homepage_sections"] as const;

export function useHomepageSections() {
  return useQuery({
    queryKey: SECTIONS_KEY,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("homepage_sections" as any)
        .select("*")
        .order("order_index");
      if (error) {
        console.error("[NB-003] homepage_sections query failed:", error.code, error.message);
        return { rows: [] as SectionRow[], map: new Map<string, SectionRow>() };
      }
      const rows = ((data ?? []) as unknown) as SectionRow[];
      const map = new Map<string, SectionRow>();
      rows.forEach((r) => map.set(r.section_key, r));
      return { rows, map };
    },
    staleTime: 60_000,
    refetchInterval: 120_000,
    retry: false,
  });
}

export function useSection(key: string): SectionRow | undefined {
  const { data } = useHomepageSections();
  return data?.map.get(key);
}

/* ============================================================
   Heavy Hitters
   ============================================================ */

export type HeavyHitterRow = {
  id: string;
  title: string;
  description: string;
  price: string;
  image_url: string | null;
  order_index: number;
  visible: boolean;
};

const HH_KEY = ["heavy_hitters"] as const;

export function useHeavyHitters(opts: { includeHidden?: boolean } = {}) {
  return useQuery({
    queryKey: [...HH_KEY, opts.includeHidden ?? false],
    queryFn: async () => {
      let req = supabase.from("heavy_hitters" as any).select("*").order("order_index");
      if (!opts.includeHidden) req = req.eq("visible", true);
      const { data, error } = await req;
      if (error) {
        console.error("[NB-004] heavy_hitters query failed:", error.code, error.message);
        return [] as HeavyHitterRow[];
      }
      return ((data ?? []) as unknown) as HeavyHitterRow[];
    },
    staleTime: 30_000,
    refetchInterval: 60_000,
    retry: false,
  });
}

/* ============================================================
   Gallery Slider
   ============================================================ */

export type GalleryRow = {
  id: string;
  section: string;
  image_url: string;
  alt: string;
  caption: string;
  order_index: number;
  visible: boolean;
};

export function useGallery(section: string, opts: { includeHidden?: boolean } = {}) {
  return useQuery({
    queryKey: ["gallery_images", section, opts.includeHidden ?? false],
    queryFn: async () => {
      let req = supabase
        .from("gallery_images" as any)
        .select("*")
        .eq("section", section)
        .order("order_index");
      if (!opts.includeHidden) req = req.eq("visible", true);
      const { data, error } = await req;
      if (error) {
        console.error("[NB-005] gallery_images query failed:", error.code, error.message);
        return [] as GalleryRow[];
      }
      return ((data ?? []) as unknown) as GalleryRow[];
    },
    staleTime: 30_000,
    refetchInterval: 60_000,
    retry: false,
  });
}

/* ============================================================
   Current crew profile
   ============================================================ */

export type CrewProfile = {
  id: string;
  email: string;
  full_name: string;
  role: "owner" | "admin" | "staff" | string;
  can_manage_users: boolean;
};

export function useCrewProfile(userId: string | undefined) {
  return useQuery({
    queryKey: ["crew_profile", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles" as any)
        .select("*")
        .eq("id", userId!)
        .maybeSingle();
      if (error) {
        console.error("[NB-006] crew_profile query failed:", error.code, error.message);
        return null;
      }
      return ((data ?? null) as unknown) as CrewProfile | null;
    },
    retry: false,
  });
}

/* ============================================================
   Upload helper (browser → storage)
   ============================================================ */

const ALLOWED_IMAGE_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/avif",
]);

const MIME_TO_EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/avif": "avif",
};

export async function uploadMedia(file: File, folder: string): Promise<string> {
  if (!ALLOWED_IMAGE_TYPES.has(file.type)) {
    throw new Error(
      `[NB-009] File type "${file.type}" not allowed. Use JPEG, PNG, WebP, GIF or AVIF.`,
    );
  }
  const ext = MIME_TO_EXT[file.type] ?? "jpg";
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from("nest-media").upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type,
  });
  if (error) throw new Error(`[NB-010] Storage upload failed: ${error.message}`);
  const { data } = supabase.storage.from("nest-media").getPublicUrl(path);
  return data.publicUrl;
}
