export type MenuItem = {
  name: string;
  nameAr?: string;
  desc: string;
  priceM?: number;
  priceL?: number;
  price?: number;
  badge?: string;
};

export type TrendingItem = {
  name: string;
  desc: string;
  price: number;
  emoji: string;
  tag: string;
};

export type MenuCategory = {
  id: string;
  title: string;
  titleAr: string;
  items: MenuItem[];
};

export const menu: MenuCategory[] = [
  {
    id: "beef",
    title: "Beef Burgers",
    titleAr: "بيف برجر",
    items: [
      { name: "Nest Burger", nameAr: "نست برجر", desc: "Two beef patties, Nest sauce, cheddar, bacon strips", priceL: 195, badge: "Signature" },
      { name: "Double Clash", nameAr: "دابل كلاش", desc: "Two beef patties, Nest sauce, cheddar, bacon strips", priceL: 190 },
      { name: "Italiano", nameAr: "إيتاليانو", desc: "Beef, mozzarella sticks, Nest sauce, cheddar", priceL: 175 },
      { name: "Double Burger", nameAr: "دابل برجر", desc: "Two beef patties, Nest sauce, cheddar", priceL: 170 },
      { name: "Mushroom Bacon", nameAr: "مشروم بيكون", desc: "Beef, Nest sauce, mushroom, cheddar, bacon", priceM: 140, priceL: 170 },
      { name: "Mini Nest", nameAr: "ميني نست", desc: "Beef, Nest sauce, mozzarella sticks, cheddar", priceM: 140, priceL: 165 },
      { name: "Clash Burger", nameAr: "كلاش", desc: "Beef, Nest sauce, cheddar, onion rings", priceM: 125, priceL: 150 },
      { name: "Volcano", nameAr: "فولكانو", desc: "Beef, Nest sauce, cheddar, mozzarella", priceL: 135 },
      { name: "Bacon Burger", nameAr: "بيكون", desc: "Beef, Nest sauce, beef bacon", priceM: 110, priceL: 135 },
      { name: "Golden", nameAr: "جولدن", desc: "Beef, Nest sauce, cheddar, mozzarella sticks", priceM: 110, priceL: 135 },
      { name: "Mushroom", nameAr: "مشروم", desc: "Beef, Nest sauce, mushroom, cheddar", priceM: 105, priceL: 130 },
      { name: "Onionity", nameAr: "أونيونيتي", desc: "Beef, Nest sauce, cheddar, onion rings", priceM: 105, priceL: 130 },
      { name: "Chilli Burger", nameAr: "تشيلي", desc: "Beef, Nest sauce, cheddar, jalapeño slices", priceM: 100, priceL: 125 },
      { name: "Old School", nameAr: "أولد سكول", desc: "Beef, Nest sauce, cheddar", priceM: 90, priceL: 105 },
    ],
  },
  {
    id: "chicken",
    title: "Chicken Burgers",
    titleAr: "تشيكن برجر",
    items: [
      { name: "Double Grilled", desc: "Two grilled chicken breasts, cheddar sauce, Nest sauce", price: 195 },
      { name: "Double Crispy", desc: "Two crispy chicken breasts, cheddar sauce, Nest sauce", price: 190 },
      { name: "Golden Crispy", desc: "Crispy chicken, mozzarella sticks, cheddar, Nest sauce", price: 140 },
      { name: "Smoked Crispy", desc: "Crispy chicken, smoked turkey, cheddar, Nest sauce", price: 135 },
      { name: "Onionity Crispy", desc: "Crispy chicken, onion rings, cheddar, Nest sauce", price: 135 },
      { name: "Crispy Ranch", desc: "Crispy chicken, cheddar sauce, ranch sauce", price: 135 },
      { name: "Grilled Chicken", desc: "Grilled chicken breast, cheddar slice, Nest sauce", price: 135 },
      { name: "Classic Crispy", desc: "Crispy chicken, cheddar sauce, Nest sauce", price: 120 },
    ],
  },
  {
    id: "appetizers",
    title: "Appetizers",
    titleAr: "مقبلات",
    items: [
      { name: "Crispy Loaded Fries", desc: "Fries loaded with cheese & crispy chicken bites", price: 100 },
      { name: "Kids Meal (Beef)", desc: "Mini burger + fries + drink", price: 99 },
      { name: "Kids Meal (Chicken)", desc: "Mini chicken + fries + drink", price: 99 },
      { name: "Chicken Pops", desc: "Crispy bite-sized chicken pieces", price: 95 },
      { name: "New York Fries", desc: "Loaded NY style fries", price: 90 },
      { name: "Cheese Fries", desc: "Fries topped with melted cheddar", price: 65 },
      { name: "Onion Rings (5pcs)", desc: "Golden crispy onion rings", price: 35 },
      { name: "Mozzarella Sticks (2pcs)", desc: "Crispy mozzarella sticks", price: 35 },
      { name: "Fries (Medium)", desc: "Classic golden fries", price: 30 },
      { name: "Fries (Large)", desc: "Classic golden fries", price: 50 },
      { name: "Coleslaw", desc: "Creamy cabbage slaw", price: 25 },
      { name: "Jalapeño", desc: "Sliced jalapeños", price: 15 },
    ],
  },
  {
    id: "sauces",
    title: "Sauces",
    titleAr: "صوصات",
    items: [
      { name: "Nest Sauce", desc: "Our signature house sauce", price: 25, badge: "House" },
      { name: "Chilli Sauce", desc: "Spicy chilli kick", price: 25 },
      { name: "Ranch Sauce", desc: "Creamy ranch", price: 20 },
      { name: "Yummy Sauce", desc: "Sweet & tangy", price: 20 },
      { name: "Cheese Sauce", desc: "Melted cheddar dip", price: 20 },
      { name: "BBQ Sauce", desc: "Smoky barbecue", price: 15 },
    ],
  },
  {
    id: "drinks",
    title: "Drinks",
    titleAr: "مشروبات",
    items: [
      { name: "V7 Cola", desc: "Chilled V7 cola", price: 25 },
      { name: "Big Cola", desc: "Big cola bottle", price: 15 },
      { name: "Water", desc: "Mineral water", price: 10 },
    ],
  },
  {
    id: "extras",
    title: "Extras",
    titleAr: "إضافات",
    items: [
      { name: "Extra Beef Patty", desc: "Add a second patty", price: 60 },
      { name: "Beef Bacon Strips", desc: "Crispy beef bacon", price: 30 },
      { name: "Mushroom", desc: "Sautéed mushrooms", price: 20 },
      { name: "Spicy Sauce", desc: "Add a spicy kick", price: 20 },
      { name: "Cheddar Slice", desc: "American cheddar", price: 15 },
      { name: "Mozzarella Sticks", desc: "Add mozzarella sticks", price: 15 },
      { name: "Jalapeño", desc: "Add jalapeños", price: 15 },
      { name: "Onion Rings", desc: "Add onion rings", price: 15 },
      { name: "Smoked Turkey", desc: "Add smoked turkey", price: 15 },
      { name: "Kaiser", desc: "Kaiser bun upgrade", price: 15 },
    ],
  },
];

export const BRAND = {
  name: "Nest Burger",
  tagline: "أصل الطعم الحقيقي",
  taglineEn: "The Real Original Taste",
  whatsapp: "201006973278",
  whatsappDisplay: "+20 100 697 3278",
  phone2: "+20 101 586 4098",
  instagram: "https://instagram.com/nestburger.eg",
  facebook: "https://facebook.com/nestburger.eg",
  whatsappUrl: "https://wa.me/201006973278?text=" + encodeURIComponent("Hi Nest Burger 👋, I'd like to place an order."),
};

export const TRENDING: TrendingItem[] = [
  { name: "Nest Burger", desc: "Two patties, Nest sauce, cheddar, bacon", price: 195, emoji: "🍔", tag: "#1 Bestseller" },
  { name: "Combo 250", desc: "Volcano + Old School Medium + fries + mozzarella sticks", price: 250, emoji: "🔥", tag: "Most Ordered" },
  { name: "Volcano", desc: "Beef, Nest sauce, cheddar, mozzarella", price: 135, emoji: "🌶️", tag: "Spicy Pick" },
  { name: "Golden Crispy", desc: "Crispy chicken, mozzarella sticks, cheddar", price: 140, emoji: "🍗", tag: "Fan Favorite" },
  { name: "Crispy Loaded Fries", desc: "Cheese loaded fries with crispy chicken bites", price: 100, emoji: "🍟", tag: "Viral Side" },
];
