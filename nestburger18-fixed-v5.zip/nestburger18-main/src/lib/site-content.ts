import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { BRAND, TRENDING } from "./menu-data";

export type SiteSettings = {
  whatsapp_number: string;
  instagram_url: string;
  facebook_url: string;
  hero_pills: string[];
};

const SETTINGS_FALLBACK: SiteSettings = {
  whatsapp_number: BRAND.whatsapp,
  instagram_url: BRAND.instagram,
  facebook_url: BRAND.facebook,
  hero_pills: ["FRESH DAILY", "HAND-CRAFTED", "SMASHED TO ORDER"],
};

export function whatsappLink(
  number: string,
  text = "Hi Nest Burger 👋, I'd like to place an order.",
) {
  const digits = (number || "").replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

export function useSiteSettings(): SiteSettings {
  const { data } = useQuery({
    queryKey: ["site_settings"],
    queryFn: async (): Promise<SiteSettings> => {
      // Read only from the public-safe view (no whatsapp_number exposed to anon).
      // whatsapp_number stays in the DB and is only fetched server-side / by crew.
      const { data, error } = await supabase
        .from("site_settings_public" as any)
        .select("instagram_url, facebook_url, hero_pills")
        .eq("id", 1)
        .maybeSingle();
      if (error) { console.error("[NB-007] site_settings_public query failed:", error.code, error.message); return SETTINGS_FALLBACK; }
      if (!data) return SETTINGS_FALLBACK;
      const pills = Array.isArray((data as any).hero_pills)
        ? ((data as any).hero_pills as string[])
        : SETTINGS_FALLBACK.hero_pills;
      return {
        // whatsapp_number is NOT read from the public DB — use the hardcoded
        // BRAND fallback for the public site. Crew admin reads it via the
        // authenticated site_settings query in nest-crew.tsx.
        whatsapp_number: SETTINGS_FALLBACK.whatsapp_number,
        instagram_url: (data as any).instagram_url || SETTINGS_FALLBACK.instagram_url,
        facebook_url: (data as any).facebook_url || SETTINGS_FALLBACK.facebook_url,
        hero_pills: pills.length ? pills : SETTINGS_FALLBACK.hero_pills,
      };
    },
    staleTime: 30_000,
  });
  return data ?? SETTINGS_FALLBACK;
}

export type TrendingRow = {
  id: string;
  name: string;
  desc: string;
  price: string;
  emoji: string;
  tag: string;
  image_url: string | null;
  visible: boolean;
  sort_order: number;
};

const TRENDING_FALLBACK: TrendingRow[] = TRENDING.map((t, i) => ({
  id: `seed-${i}`,
  name: t.name,
  desc: t.desc,
  price: String(t.price),
  emoji: t.emoji,
  tag: t.tag,
  image_url: null,
  visible: true,
  sort_order: i,
}));

export function useTrending(opts: { includeHidden?: boolean } = {}): TrendingRow[] {
  const { data } = useQuery({
    queryKey: ["trending_items", opts.includeHidden ?? false],
    queryFn: async (): Promise<TrendingRow[]> => {
      let q = supabase.from("trending_items").select("*").order("sort_order");
      if (!opts.includeHidden) q = q.eq("visible", true);
      const { data, error } = await q;
      if (error) { console.error("[NB-008] trending_items query failed:", error.code, error.message); return TRENDING_FALLBACK; }
      if (!data) return TRENDING_FALLBACK;
      return (data as any[]).map((d) => ({
        id: d.id,
        name: d.name,
        desc: d.description ?? "",
        price: String(d.price ?? ""),
        emoji: d.emoji ?? "🔥",
        tag: d.tag ?? "",
        image_url: d.image_url,
        visible: d.visible,
        sort_order: d.sort_order,
      }));
    },
    staleTime: 30_000,
  });
  return data ?? TRENDING_FALLBACK;
}
