import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { menu, BRAND, type MenuItem } from "@/lib/menu-data";
import { Reveal } from "./Reveal";

function PriceTag({ item }: { item: MenuItem }) {
  if (item.price !== undefined) {
    return (
      <span className="font-display text-lg text-[var(--gold)]">
        {item.price}
        <span className="text-xs ml-0.5">LE</span>
      </span>
    );
  }
  return (
    <div className="flex items-center gap-2 text-sm">
      {item.priceM !== undefined && (
        <span className="font-semibold">
          M <span className="text-[var(--gold)] font-display text-base">{item.priceM}</span>
        </span>
      )}
      {item.priceL !== undefined && (
        <span className="font-semibold">
          L <span className="text-[var(--gold)] font-display text-base">{item.priceL}</span>
        </span>
      )}
    </div>
  );
}

export function MenuSection() {
  const [active, setActive] = useState(menu[0].id);
  const cat = menu.find((c) => c.id === active)!;

  return (
    <section id="menu" className="relative py-24 sm:py-32 noise-bg">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="text-center mb-14">
            <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
              Full Menu
            </span>
            <h2 className="font-display text-5xl sm:text-7xl mt-2 leading-none">
              Pick Your <span className="gold-text">Poison</span>
            </h2>
            <p className="mt-4 text-foreground/60 max-w-xl mx-auto">
              From signature beef stacks to crispy chicken — every item handmade fresh.
            </p>
          </div>
        </Reveal>

        {/* Categories */}
        <Reveal delay={0.1}>
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {menu.map((c) => (
              <button
                key={c.id}
                onClick={() => setActive(c.id)}
                className={`relative rounded-full px-5 py-2.5 text-sm font-semibold transition-all duration-300 ${
                  active === c.id
                    ? "text-[var(--primary-foreground)]"
                    : "text-foreground/80 hover:text-foreground frost hover:frost-hover"
                }`}
              >
                {active === c.id && (
                  <motion.span
                    layoutId="cat-pill"
                    className="absolute inset-0 rounded-full bg-[var(--gold)] gold-glow"
                    transition={{ type: "spring", stiffness: 400, damping: 32 }}
                  />
                )}
                <span className="relative">{c.title}</span>
              </button>
            ))}
          </div>
        </Reveal>

        <AnimatePresence mode="wait">
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {cat.items.map((it, i) => (
              <motion.div
                key={it.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.04 }}
                whileHover={{ y: -4 }}
                className="group relative rounded-2xl frost p-5 transition-all duration-300 hover:frost-hover hover:-translate-y-1 hover:gold-glow overflow-hidden"
              >
                <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-4 items-start">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-display text-lg tracking-wide truncate">{it.name}</h3>
                      {it.badge && (
                        <span className="text-[9px] font-bold tracking-widest rounded-full bg-[var(--gold)]/15 text-[var(--gold)] px-2 py-0.5">
                          {it.badge.toUpperCase()}
                        </span>
                      )}
                    </div>
                    {it.nameAr && (
                      <div className="text-xs text-foreground/50 mt-0.5" dir="rtl">
                        {it.nameAr}
                      </div>
                    )}
                    <p className="text-xs text-foreground/65 mt-2 leading-relaxed">{it.desc}</p>
                  </div>
                  <PriceTag item={it} />
                </div>
                <a
                  href={`${BRAND.whatsappUrl.split("?")[0]}?text=${encodeURIComponent(
                    `Hi Nest Burger 👋, I'd like to order: ${it.name}`,
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--gold)] opacity-70 group-hover:opacity-100 transition-opacity"
                >
                  <MessageCircle className="h-3 w-3" /> Order this
                </a>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
