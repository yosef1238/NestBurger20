import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowDown, MessageCircle, Flame } from "lucide-react";
import heroBurger from "@/assets/nest-hero.jpg";
import { useImage } from "@/lib/cms";
import { BRAND } from "@/lib/menu-data";
import { useSiteSettings, whatsappLink } from "@/lib/site-content";

export function Hero() {
  const settings = useSiteSettings();
  const waUrl = whatsappLink(settings.whatsapp_number);
  const pills = settings.hero_pills;
  // useImage must be called at the top level of the component, not inside JSX.
  const heroSrc = useImage("homepage.hero.background", heroBurger);
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yImg = useTransform(scrollYProgress, [0, 1], [0, 220]);
  const scaleImg = useTransform(scrollYProgress, [0, 1], [1, 1.15]);
  const yText = useTransform(scrollYProgress, [0, 1], [0, -120]);
  const opacityText = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  return (
    <section id="home" ref={ref} className="relative min-h-screen overflow-hidden noise-bg">
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 h-[600px] w-[600px] rounded-full bg-[var(--gold)]/15 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[400px] w-[400px] rounded-full bg-[var(--ember)]/15 blur-[140px]" />
      </div>

      {/* Floating pixel pills — owner editable */}
      <div className="absolute top-28 inset-x-0 z-10 pointer-events-none hidden md:block">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 flex flex-wrap justify-between gap-3">
          {pills.map((label, i) => (
            <motion.div
              key={`${label}-${i}`}
              animate={{ y: [0, i % 2 === 0 ? -14 : 14, 0] }}
              transition={{ duration: 6 + i, repeat: Infinity, ease: "easeInOut", delay: i * 0.4 }}
              className="glass rounded-2xl px-4 py-3 flex items-center gap-2"
            >
              {i === 0 && <Flame className="h-3.5 w-3.5 text-[var(--gold)]" />}
              <span className={`font-pixel text-[10px] sm:text-[11px] ${i === 0 ? "text-[var(--gold)]" : "text-foreground/90"}`}>
                {label}
              </span>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-36 sm:pt-44 pb-16">
        <motion.div style={{ y: yText, opacity: opacityText }} className="relative z-10 text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 mb-6"
          >
            <span className="h-2 w-2 rounded-full bg-[var(--gold)] animate-pulse" />
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-foreground/80">
              {BRAND.taglineEn} · {BRAND.tagline}
            </span>
          </motion.div>

          <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl leading-[0.95] tracking-tight">
            <motion.span
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="block"
            >
              CRAFTED FOR
            </motion.span>
            <motion.span
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
              className="block shimmer-text"
            >
              REAL BURGER
            </motion.span>
            <motion.span
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="block"
            >
              LOVERS.
            </motion.span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.85 }}
            className="mt-6 text-base sm:text-lg text-foreground/70 max-w-xl mx-auto"
          >
            Hand-pressed patties, signature Nest sauce, and that one bite that
            ruins every other burger for you. Forever.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="mt-9 flex flex-wrap items-center justify-center gap-3"
          >
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative inline-flex items-center gap-2 rounded-full bg-[var(--gold)] px-7 py-4 text-sm font-bold text-[var(--primary-foreground)] gold-glow transition-transform duration-300 hover:scale-[1.04]"
            >
              <MessageCircle className="h-4 w-4" />
              ORDER ON WHATSAPP
              <span className="absolute inset-0 rounded-full bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
            </a>
            <a
              href="#menu"
              className="inline-flex items-center gap-2 rounded-full glass px-7 py-4 text-sm font-semibold transition-all duration-300 hover:bg-white/10"
            >
              EXPLORE MENU
              <ArrowDown className="h-4 w-4" />
            </a>
          </motion.div>
        </motion.div>

        <motion.div
          style={{ y: yImg, scale: scaleImg }}
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="relative z-0 mt-12 sm:mt-16 mx-auto max-w-3xl"
        >
          <div className="relative animate-float">
            <div className="absolute inset-0 -z-10 rounded-[2.5rem] bg-[var(--gold)]/30 blur-[100px]" />
            <div className="relative mx-auto max-w-xl rounded-[2.5rem] overflow-hidden border border-white/10 shadow-[0_40px_80px_rgba(0,0,0,0.6)] gold-glow">
              <img
                src={heroSrc}
                alt="Nest Burger signature cheeseburger"
                className="w-full h-auto object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Marquee */}
      <div className="relative border-y border-white/10 bg-black/40 py-5 overflow-hidden">
        <div className="flex gap-12 animate-marquee whitespace-nowrap font-display text-2xl sm:text-3xl tracking-widest">
          {Array.from({ length: 2 }).map((_, k) => (
            <div key={k} className="flex gap-12 shrink-0">
              {["FRESH BEEF", "★", "NEST SAUCE", "★", "CRISPY CHICKEN", "★", "LOADED FRIES", "★", "ORDER ON WHATSAPP", "★"].map(
                (w, i) => (
                  <span key={`${k}-${i}`} className={i % 2 === 0 ? "text-foreground" : "text-[var(--gold)]"}>
                    {w}
                  </span>
                ),
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
