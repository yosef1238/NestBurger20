import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { useSiteSettings, whatsappLink } from "@/lib/site-content";

export function FloatingOrder() {
  const settings = useSiteSettings();
  return (
    <motion.a
      href={whatsappLink(settings.whatsapp_number)}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 2, type: "spring", stiffness: 200, damping: 18 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.94 }}
      className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 rounded-full bg-[var(--gold)] pl-4 pr-5 py-3.5 text-sm font-bold text-[var(--primary-foreground)] shadow-2xl gold-glow animate-pulse-glow"
      aria-label="Order on WhatsApp"
    >
      <MessageCircle className="h-5 w-5" />
      <span className="hidden sm:inline">Order</span>
    </motion.a>
  );
}
