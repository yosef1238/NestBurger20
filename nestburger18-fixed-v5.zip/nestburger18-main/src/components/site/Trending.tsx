import { motion } from "framer-motion";
import { Flame, MessageCircle, TrendingUp } from "lucide-react";
import { Reveal } from "./Reveal";
import { useSiteSettings, useTrending, whatsappLink } from "@/lib/site-content";

export function Trending() {
  const settings = useSiteSettings();
  const items = useTrending();

  if (!items.length) return null;

  return (
    <section id="trending" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[700px] w-[700px] rounded-full bg-[var(--gold)]/10 blur-[160px] pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 mb-4">
                <TrendingUp className="h-3.5 w-3.5 text-[var(--gold)]" />
                <span className="text-xs font-bold tracking-[0.2em] text-[var(--gold)] uppercase">
                  Trending Now
                </span>
              </div>
              <h2 className="font-display text-4xl sm:text-6xl leading-none">
                What's <span className="gold-text">Hot</span> Today
              </h2>
            </div>
            <p className="text-foreground/60 max-w-md">
              The items everyone is ordering right now. Add them to your chat in one tap.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {items.map((item, i) => {
            const orderUrl = whatsappLink(
              settings.whatsapp_number,
              `Hi Nest Burger 👋, I want to order: ${item.name}`,
            );
            return (
              <Reveal key={item.id} delay={i * 0.08}>
                <motion.div
                  whileHover={{ y: -8, scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 300, damping: 22 }}
                  className="group relative flex flex-col rounded-3xl frost p-5 h-full border border-white/10 overflow-hidden"
                >
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-[var(--gold)]/10 via-transparent to-[var(--ember)]/10" />

                  {item.image_url && (
                    <div className="relative -mx-5 -mt-5 mb-4 h-32 overflow-hidden rounded-t-3xl">
                      <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    </div>
                  )}

                  {item.tag && (
                    <div className="relative flex items-start justify-end mb-4">
                      <span className="inline-flex items-center gap-1 rounded-full bg-[var(--gold)]/15 px-2.5 py-1 text-[10px] font-bold tracking-wider text-[var(--gold)]">
                        <Flame className="h-3 w-3" />
                        {item.tag.toUpperCase()}
                      </span>
                    </div>
                  )}

                  <div className="relative mt-auto">
                    <h3 className="font-display text-2xl leading-tight">{item.name}</h3>
                    <p className="text-sm text-foreground/60 mt-1 line-clamp-2">{item.desc}</p>
                    <div className="mt-4 flex items-center justify-between gap-3">
                      <div className="font-display text-2xl text-[var(--gold)]">
                        {item.price}
                        <span className="text-sm ml-1">LE</span>
                      </div>
                      <a
                        href={orderUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 rounded-full bg-[var(--gold)] px-3 py-2 text-xs font-bold text-[var(--primary-foreground)] transition-transform hover:scale-105"
                      >
                        <MessageCircle className="h-3 w-3" /> Order
                      </a>
                    </div>
                  </div>
                </motion.div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
