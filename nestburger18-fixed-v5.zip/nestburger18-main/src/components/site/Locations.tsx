import { motion } from "framer-motion";
import { MapPin, Phone, Clock } from "lucide-react";
import { Reveal } from "./Reveal";
import { BRAND } from "@/lib/menu-data";

const branches = [
  { name: "Main Branch", area: "Cairo · Egypt", phone: BRAND.whatsappDisplay, hours: "12:00 PM — 3:00 AM" },
  { name: "Second Branch", area: "Cairo · Egypt", phone: BRAND.phone2, hours: "12:00 PM — 3:00 AM" },
];

export function Locations() {
  return (
    <section id="locations" className="relative py-24 sm:py-32 noise-bg">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="text-center mb-14">
            <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
              Find Us
            </span>
            <h2 className="font-display text-5xl sm:text-7xl mt-2 leading-none">
              Our <span className="gold-text">Branches</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {branches.map((b, i) => (
            <Reveal key={b.name} delay={i * 0.1}>
              <motion.div
                whileHover={{ y: -6 }}
                className="relative rounded-3xl glass p-7 sm:p-9 overflow-hidden hover:gold-glow transition-all duration-500"
              >
                <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-[var(--gold)]/10 blur-3xl" />
                <MapPin className="h-8 w-8 text-[var(--gold)]" />
                <h3 className="font-display text-3xl mt-4">{b.name}</h3>
                <p className="text-foreground/60 mt-1">{b.area}</p>
                <div className="mt-6 space-y-3 text-sm">
                  <a href={`tel:${b.phone.replace(/\s/g, "")}`} className="flex items-center gap-3 hover:text-[var(--gold)] transition">
                    <Phone className="h-4 w-4 text-[var(--gold)]" /> {b.phone}
                  </a>
                  <div className="flex items-center gap-3 text-foreground/70">
                    <Clock className="h-4 w-4 text-[var(--gold)]" /> {b.hours}
                  </div>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
