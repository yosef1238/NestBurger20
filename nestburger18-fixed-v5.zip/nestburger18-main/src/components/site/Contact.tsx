import { motion } from "framer-motion";
import { MessageCircle, Instagram, Facebook, Phone } from "lucide-react";
import { Reveal } from "./Reveal";
import { useSiteSettings, whatsappLink } from "@/lib/site-content";

export function Contact() {
  const settings = useSiteSettings();
  const waNumber = settings.whatsapp_number.replace(/\D/g, "");
  const waUrl = whatsappLink(settings.whatsapp_number);
  return (
    <section id="contact" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[500px] w-[500px] rounded-full bg-[var(--gold)]/10 blur-[120px]" />
      </div>
      <div className="relative mx-auto max-w-4xl px-4 sm:px-6 text-center">
        <Reveal>
          <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
            Hungry?
          </span>
          <h2 className="font-display text-5xl sm:text-7xl lg:text-8xl mt-2 leading-[0.9]">
            Let's <br /> <span className="gold-text shimmer-text">Get You Fed.</span>
          </h2>
          <p className="mt-6 text-foreground/70 max-w-xl mx-auto">
            Tap the button. Chat with us on WhatsApp. Your burger is 20 minutes away.
          </p>
        </Reveal>

        <Reveal delay={0.2}>
          <motion.a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.98 }}
            className="mt-10 inline-flex items-center gap-3 rounded-full bg-[var(--gold)] px-9 py-5 text-base font-bold text-[var(--primary-foreground)] gold-glow"
          >
            <MessageCircle className="h-5 w-5" /> ORDER ON WHATSAPP
          </motion.a>
        </Reveal>

        <Reveal delay={0.3}>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            {[
              { Icon: Phone, label: `+${waNumber}`, href: `tel:+${waNumber}` },
              { Icon: Instagram, label: "Instagram", href: settings.instagram_url },
              { Icon: Facebook, label: "Facebook", href: settings.facebook_url },
            ].map(({ Icon, label, href }) => (
              <a
                key={label}
                href={href}
                target={href.startsWith("http") ? "_blank" : undefined}
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full glass px-5 py-3 text-sm font-medium hover:bg-white/10 hover:text-[var(--gold)] transition"
              >
                <Icon className="h-4 w-4 text-[var(--gold)]" />
                {label}
              </a>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
