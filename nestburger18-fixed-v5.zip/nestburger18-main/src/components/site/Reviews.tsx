import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Reveal } from "./Reveal";

const reviews = [
  { n: "Ahmed M.", t: "The Nest Burger is honestly unreal. Best in the area, full stop.", r: 5 },
  { n: "Salma K.", t: "Crispy chicken hits every time. The sauce is dangerous.", r: 5 },
  { n: "Omar A.", t: "Double Clash + Loaded Fries = perfect night. Delivery was fast too.", r: 5 },
  { n: "Nour H.", t: "I keep ordering the Italiano. That mozzarella stick inside is genius.", r: 5 },
  { n: "Youssef R.", t: "Quality is consistent every single time. That matters.", r: 5 },
  { n: "Mariam S.", t: "Mini Nest is small in name only. Loaded with flavor.", r: 5 },
];

export function Reviews() {
  return (
    <section className="relative py-24 sm:py-32 noise-bg">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="text-center mb-14">
            <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
              The Verdict
            </span>
            <h2 className="font-display text-5xl sm:text-7xl mt-2 leading-none">
              Loved By <span className="gold-text">The Real Ones</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {reviews.map((r, i) => (
            <Reveal key={r.n} delay={i * 0.06}>
              <motion.div whileHover={{ y: -6 }} className="h-full rounded-2xl glass p-6 hover:gold-glow transition-all duration-500">
                <div className="flex gap-1 mb-3">
                  {Array.from({ length: r.r }).map((_, k) => (
                    <Star key={k} className="h-4 w-4 fill-[var(--gold)] text-[var(--gold)]" />
                  ))}
                </div>
                <p className="text-sm text-foreground/85 leading-relaxed">"{r.t}"</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="grid h-9 w-9 place-items-center rounded-full bg-[var(--gold)]/20 text-[var(--gold)] font-display">
                    {r.n[0]}
                  </div>
                  <span className="text-sm font-semibold">{r.n}</span>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
