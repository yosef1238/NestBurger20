import { Instagram, Facebook, MessageCircle } from "lucide-react";
import { BRAND } from "@/lib/menu-data";
import { useSiteSettings, whatsappLink } from "@/lib/site-content";

export function Footer() {
  const settings = useSiteSettings();
  return (
    <footer className="relative border-t border-white/10 bg-black/40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-10">
        <div>
          <div className="flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-full bg-[var(--gold)] text-[var(--primary-foreground)] font-display text-xl">
              N
            </div>
            <span className="font-display text-xl tracking-wider">
              NEST<span className="text-[var(--gold)]">BURGER</span>
            </span>
          </div>
          <p className="mt-4 text-sm text-foreground/60 max-w-xs">
            {BRAND.taglineEn}. Hand-pressed patties, signature sauce, no shortcuts.
          </p>
          <div className="mt-4 text-sm text-foreground/60" dir="rtl">
            {BRAND.tagline}
          </div>
        </div>

        <div>
          <div className="text-xs font-bold tracking-widest text-[var(--gold)] mb-4">EXPLORE</div>
          <ul className="space-y-2 text-sm text-foreground/70">
            {["Featured", "Menu", "About", "Offers", "Branches"].map((l) => (
              <li key={l}>
                <a href={`#${l.toLowerCase()}`} className="hover:text-[var(--gold)] transition">
                  {l}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <div className="text-xs font-bold tracking-widest text-[var(--gold)] mb-4">CONNECT</div>
          <div className="flex gap-2 flex-wrap">
            <a href={whatsappLink(settings.whatsapp_number)} target="_blank" rel="noopener noreferrer" className="grid h-11 w-11 place-items-center rounded-full glass hover:bg-[var(--gold)] hover:text-[var(--primary-foreground)] transition">
              <MessageCircle className="h-4 w-4" />
            </a>
            <a href={settings.instagram_url} target="_blank" rel="noopener noreferrer" className="grid h-11 w-11 place-items-center rounded-full glass hover:bg-[var(--gold)] hover:text-[var(--primary-foreground)] transition">
              <Instagram className="h-4 w-4" />
            </a>
            <a href={settings.facebook_url} target="_blank" rel="noopener noreferrer" className="grid h-11 w-11 place-items-center rounded-full glass hover:bg-[var(--gold)] hover:text-[var(--primary-foreground)] transition">
              <Facebook className="h-4 w-4" />
            </a>
          </div>
          <div className="mt-4 text-sm text-foreground/60">
            +{settings.whatsapp_number.replace(/\D/g, "")}
          </div>
        </div>
      </div>
      <div className="border-t border-white/5">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-5 text-xs text-foreground/50 flex flex-wrap justify-between gap-2">
          <span>© {new Date().getFullYear()} Nest Burger. All rights reserved.</span>
          <span>Crafted for real burger lovers.</span>
        </div>
      </div>
    </footer>
  );
}
