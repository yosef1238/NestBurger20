import { motion } from "framer-motion";
import { useRef } from "react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { ChevronLeft, ChevronRight, MessageCircle, Trophy } from "lucide-react";
import { Reveal } from "./Reveal";
import { useHeavyHitters } from "@/lib/cms";
import { useSiteSettings, whatsappLink } from "@/lib/site-content";
import { useSection } from "@/lib/cms";

export function HeavyHitters() {
  const { data: items = [] } = useHeavyHitters();
  const settings = useSiteSettings();
  const section = useSection("heavy_hitters");

  const autoplay = useRef(Autoplay({ delay: 5000, stopOnInteraction: true }));
  const [emblaRef, emblaApi] = useEmblaCarousel(
    { loop: true, align: "start", containScroll: "trimSnaps" },
    [autoplay.current],
  );

  if (!items.length) return null;
  const useSlider = items.length > 3;
  const title = section?.title || "Top Heavy Hitters";
  const subtitle = section?.subtitle || "The crowd favorites";

  return (
    <section id="heavy-hitters" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute top-0 right-0 h-[500px] w-[500px] rounded-full bg-[var(--ember)]/10 blur-[160px] pointer-events-none" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 mb-4">
                <Trophy className="h-3.5 w-3.5 text-[var(--gold)]" />
                <span className="text-xs font-bold tracking-[0.2em] text-[var(--gold)] uppercase">
                  {subtitle}
                </span>
              </div>
              <h2 className="font-display text-4xl sm:text-6xl leading-none">
                {title.split(" ").map((w, i, arr) =>
                  i === arr.length - 1 ? (
                    <span key={i} className="gold-text"> {w}</span>
                  ) : (
                    <span key={i}>{i > 0 ? " " : ""}{w}</span>
                  ),
                )}
              </h2>
            </div>
            {section?.body && (
              <p className="text-foreground/60 max-w-md">{section.body}</p>
            )}
          </div>
        </Reveal>

        {useSlider ? (
          <div className="relative">
            <div className="overflow-hidden" ref={emblaRef}>
              <div className="flex gap-5">
                {items.map((item, i) => (
                  <div
                    key={item.id}
                    className="flex-[0_0_85%] sm:flex-[0_0_45%] lg:flex-[0_0_31%] min-w-0"
                  >
                    <HeavyHitterCard item={item} i={i} whatsapp={settings.whatsapp_number} />
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-6 flex justify-center gap-2">
              <button
                onClick={() => emblaApi?.scrollPrev()}
                className="grid h-10 w-10 place-items-center rounded-full glass border border-white/10 hover:border-[var(--gold)]/40 transition"
                aria-label="Previous"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                onClick={() => emblaApi?.scrollNext()}
                className="grid h-10 w-10 place-items-center rounded-full glass border border-white/10 hover:border-[var(--gold)]/40 transition"
                aria-label="Next"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {items.map((item, i) => (
              <HeavyHitterCard key={item.id} item={item} i={i} whatsapp={settings.whatsapp_number} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function HeavyHitterCard({
  item,
  i,
  whatsapp,
}: {
  item: { id: string; title: string; description: string; price: string; image_url: string | null };
  i: number;
  whatsapp: string;
}) {
  const orderUrl = whatsappLink(whatsapp, `Hi Nest Burger 👋, I want to order: ${item.title}`);
  return (
    <Reveal delay={i * 0.08}>
      <motion.div
        whileHover={{ y: -10, scale: 1.02 }}
        transition={{ type: "spring", stiffness: 280, damping: 22 }}
        className="group relative flex flex-col rounded-3xl frost border border-white/10 overflow-hidden h-full"
      >
        <div className="relative h-56 overflow-hidden bg-black/40">
          {item.image_url ? (
            <img
              src={item.image_url}
              alt={item.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
          ) : (
            <div className="grid h-full w-full place-items-center text-foreground/30">
              <Trophy className="h-12 w-12" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute top-3 left-3 inline-flex items-center gap-1 rounded-full bg-[var(--ember)]/90 px-2.5 py-1 text-[10px] font-bold tracking-wider text-white">
            <Trophy className="h-3 w-3" />
            HEAVY HITTER
          </div>
        </div>
        <div className="relative p-5 flex-1 flex flex-col">
          <h3 className="font-display text-2xl leading-tight">{item.title}</h3>
          {item.description && (
            <p className="text-sm text-foreground/60 mt-1.5 line-clamp-2">{item.description}</p>
          )}
          <div className="mt-auto pt-4 flex items-center justify-between gap-3">
            <div className="font-display text-2xl text-[var(--gold)]">{item.price}</div>
            <a
              href={orderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full bg-[var(--gold)] px-4 py-2 text-xs font-bold text-[var(--primary-foreground)] transition-transform hover:scale-105"
            >
              <MessageCircle className="h-3.5 w-3.5" /> Order
            </a>
          </div>
        </div>
      </motion.div>
    </Reveal>
  );
}
