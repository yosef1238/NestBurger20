import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import featured from "@/assets/nest-team.jpg";
import { useImage } from "@/lib/cms";
import { Reveal } from "./Reveal";
import { Flame, Beef, Sparkles } from "lucide-react";

const stats = [
  { k: "100%", v: "Pure Beef" },
  { k: "14+", v: "Beef Burgers" },
  { k: "8", v: "Chicken Builds" },
  { k: "Daily", v: "Fresh Prep" },
];

export function About() {
  // useImage must be called at the top level of the component, not inside JSX.
  const aboutSrc = useImage("homepage.about.image", featured);
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [-60, 60]);

  return (
    <section id="about" ref={ref} className="relative py-24 sm:py-32 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        <Reveal>
          <div>
            <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
              About Nest Burger
            </span>
            <h2 className="font-display text-4xl sm:text-6xl mt-2 leading-[0.95]">
              The Real <br /> <span className="gold-text">Original Taste</span>
            </h2>
            <p className="mt-6 text-foreground/70 leading-relaxed">
              Nest Burger was built on a single idea: a burger should taste like
              someone actually cared. We grind fresh, season hard, and toast every
              bun like it's the last one. Our signature Nest sauce is the reason
              you'll be back tomorrow.
            </p>

            <div className="mt-8 grid grid-cols-3 gap-4">
              {[
                { Icon: Beef, t: "Fresh Beef" },
                { Icon: Flame, t: "Flame-Grilled" },
                { Icon: Sparkles, t: "House Sauces" },
              ].map(({ Icon, t }) => (
                <div key={t} className="rounded-2xl glass p-4 text-center">
                  <Icon className="h-6 w-6 mx-auto text-[var(--gold)]" />
                  <div className="mt-2 text-xs font-semibold">{t}</div>
                </div>
              ))}
            </div>

            <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
              {stats.map((s) => (
                <div key={s.v} className="rounded-2xl bg-[var(--surface)] p-4 border border-white/5">
                  <div className="font-display text-2xl text-[var(--gold)]">{s.k}</div>
                  <div className="text-xs text-foreground/60 mt-1">{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <motion.div style={{ y }} className="relative">
          <Reveal y={60}>
            <div className="relative rounded-[2rem] overflow-hidden gold-glow">
              <img src={aboutSrc} alt="The Nest Burger team" loading="lazy" className="w-full h-auto object-cover" />
              <div className="absolute bottom-4 left-4 right-4 glass rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="font-display text-lg">The crew behind the bite.</div>
                  <div className="text-xs text-foreground/60">Made with obsession, not shortcuts.</div>
                </div>
                <div className="font-display text-2xl text-[var(--gold)]">NEST</div>
              </div>
            </div>
          </Reveal>
        </motion.div>
      </div>
    </section>
  );
}
