import { motion } from "framer-motion";
import { MessageCircle, Zap } from "lucide-react";
import { Reveal } from "./Reveal";
import { BRAND } from "@/lib/menu-data";
import comboImg from "@/assets/nest-combo.jpg";
import trioImg from "@/assets/nest-trio.jpg";

const offers = [
  {
    title: "Combo 250",
    sub: "Volcano + Old School Medium + Fries + Mozzarella Sticks + Sauce",
    price: 250,
    img: comboImg,
    big: true,
  },
  {
    title: "Najda Box",
    sub: "Three signature burgers — built for the squad",
    price: 320,
    img: trioImg,
  },
];

export function Offers() {
  return (
    <section id="offers" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="text-center mb-14">
            <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
              Limited Offers
            </span>
            <h2 className="font-display text-5xl sm:text-7xl mt-2 leading-none">
              Deals That <span className="gold-text">Hit Different</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {offers.map((o, i) => (
            <Reveal
              key={o.title}
              delay={i * 0.1}
              className={o.big ? "lg:col-span-2" : "lg:col-span-1"}
            >
              <motion.div
                whileHover={{ y: -6 }}
                className="group relative overflow-hidden rounded-3xl bg-[var(--surface)] border border-white/5 h-full"
              >
                <div className="absolute inset-0">
                  <img src={o.img} alt={o.title} loading="lazy" className="h-full w-full object-cover opacity-40 group-hover:scale-110 group-hover:opacity-60 transition-all duration-1000" />
                  <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/40 to-transparent" />
                </div>
                <div className="relative p-7 sm:p-10 flex flex-col h-full min-h-[280px]">
                  <div className="inline-flex items-center gap-2 rounded-full bg-[var(--gold)]/20 px-3 py-1 w-fit">
                    <Zap className="h-3 w-3 text-[var(--gold)]" />
                    <span className="text-[10px] font-bold tracking-widest text-[var(--gold)]">LIMITED</span>
                  </div>
                  <h3 className="font-display text-3xl sm:text-5xl mt-4">{o.title}</h3>
                  <p className="mt-2 text-sm text-foreground/70 max-w-md">{o.sub}</p>
                  <div className="mt-auto pt-8 flex items-end justify-between gap-4">
                    <div>
                      <div className="text-xs text-foreground/60">Only</div>
                      <div className="font-display text-5xl sm:text-6xl text-[var(--gold)]">
                        {o.price}<span className="text-2xl ml-1">LE</span>
                      </div>
                    </div>
                    <a
                      href={`${BRAND.whatsappUrl.split("?")[0]}?text=${encodeURIComponent(`Hi Nest Burger 👋, I want the ${o.title} offer.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-full bg-[var(--gold)] px-5 py-3 text-sm font-bold text-[var(--primary-foreground)] hover:gold-glow transition-all"
                    >
                      <MessageCircle className="h-4 w-4" /> Claim
                    </a>
                  </div>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
