import { motion } from "framer-motion";
import nestHero from "@/assets/nest-hero.jpg";
import nestCombo from "@/assets/nest-combo.jpg";
import nestTrio from "@/assets/nest-trio.jpg";
import nestTeam from "@/assets/nest-team.jpg";
import { Reveal } from "./Reveal";
import { Instagram } from "lucide-react";
import { BRAND } from "@/lib/menu-data";

const imgs = [nestHero, nestTrio, nestCombo, nestTeam];

export function Gallery() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
            <div>
              <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
                Gallery
              </span>
              <h2 className="font-display text-4xl sm:text-6xl mt-2 leading-none">
                Eat With Your <span className="gold-text">Eyes</span>
              </h2>
            </div>
            <a
              href={BRAND.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 self-start rounded-full glass px-5 py-3 text-sm font-semibold hover:bg-white/10 transition"
            >
              <Instagram className="h-4 w-4 text-[var(--gold)]" /> @nestburger.eg
            </a>
          </div>
        </Reveal>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          {imgs.map((src, i) => (
            <Reveal key={i} delay={i * 0.06}>
              <motion.a
                href={BRAND.instagram}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 0.98 }}
                className="group relative block overflow-hidden rounded-2xl aspect-[4/5]"
              >
                <motion.img
                  src={src}
                  alt={`Nest Burger photo ${i + 1}`}
                  loading="lazy"
                  className="h-full w-full object-cover"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-500 grid place-items-center opacity-0 group-hover:opacity-100">
                  <Instagram className="h-8 w-8 text-[var(--gold)]" />
                </div>
              </motion.a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
