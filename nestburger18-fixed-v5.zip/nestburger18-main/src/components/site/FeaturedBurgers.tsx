import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import heroBurger from "@/assets/nest-hero.jpg";
import comboImg from "@/assets/nest-combo.jpg";
import trioImg from "@/assets/nest-trio.jpg";
import { Reveal } from "./Reveal";
import { BRAND } from "@/lib/menu-data";

const featured = [
  { name: "Nest Burger", tag: "Signature", price: 195, img: heroBurger, desc: "Two beef patties, Nest sauce, cheddar, bacon" },
  { name: "Najda Box", tag: "Trio", price: 320, img: trioImg, desc: "Three burgers — the legendary squad-share box" },
  { name: "Combo 250", tag: "Deal", price: 250, img: comboImg, desc: "Volcano + Old School Medium + fries + mozzarella sticks" },
];

export function FeaturedBurgers() {
  return (
    <section id="featured" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
            <div>
              <span className="text-xs font-semibold tracking-[0.25em] text-[var(--gold)] uppercase">
                Hand-picked
              </span>
              <h2 className="font-display text-4xl sm:text-6xl mt-2 leading-none">
                The Heavy <span className="gold-text">Hitters</span>
              </h2>
            </div>
            <p className="text-foreground/60 max-w-md">
              The three burgers our regulars keep coming back for. Built bold, served fast.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {featured.map((b, i) => (
            <Reveal key={b.name} delay={i * 0.1}>
              <motion.a
                href={BRAND.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ y: -8 }}
                transition={{ type: "spring", stiffness: 300, damping: 22 }}
                className="group relative block rounded-3xl overflow-hidden bg-[var(--surface)] border border-white/5"
              >
                <div className="relative aspect-[4/5] overflow-hidden">
                  <motion.img
                    src={b.img}
                    alt={b.name}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover"
                    whileHover={{ scale: 1.12 }}
                    transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
                  <span className="absolute top-4 left-4 rounded-full bg-[var(--gold)] px-3 py-1 text-[10px] font-bold tracking-widest text-[var(--primary-foreground)]">
                    {b.tag.toUpperCase()}
                  </span>
                  <div className="absolute bottom-0 inset-x-0 p-6">
                    <div className="flex items-end justify-between gap-4">
                      <div>
                        <h3 className="font-display text-2xl sm:text-3xl leading-tight">{b.name}</h3>
                        <p className="text-sm text-foreground/70 mt-1 line-clamp-2">{b.desc}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xs text-foreground/60">from</div>
                        <div className="font-display text-2xl text-[var(--gold)]">{b.price}<span className="text-sm">LE</span></div>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center gap-2 text-xs font-semibold text-[var(--gold)] opacity-0 group-hover:opacity-100 transition-opacity duration-500 -translate-y-2 group-hover:translate-y-0">
                      ORDER NOW <ArrowRight className="h-3 w-3" />
                    </div>
                  </div>
                </div>
              </motion.a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
