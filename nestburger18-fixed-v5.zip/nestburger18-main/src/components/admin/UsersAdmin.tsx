import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Crown, Loader2, Mail, Shield, Trash2, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { inviteCrewUser, removeCrewUser, updateCrewUser } from "@/lib/crew.functions";

type Profile = {
  id: string;
  email: string;
  full_name: string;
  role: "owner" | "admin" | "staff" | string;
  can_manage_users: boolean;
};

export function UsersAdmin({ currentUserId }: { currentUserId: string }) {
  const qc = useQueryClient();
  const invite = useServerFn(inviteCrewUser);
  const update = useServerFn(updateCrewUser);
  const remove = useServerFn(removeCrewUser);

  const { data: profiles, isLoading } = useQuery({
    queryKey: ["profiles", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles" as any).select("*").order("created_at");
      if (error) throw error;
      return ((data ?? []) as unknown) as Profile[];
    },
  });

  const { data: pending } = useQuery({
    queryKey: ["pending_crew", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("pending_crew" as any).select("*").order("created_at");
      if (error) throw error;
      return ((data ?? []) as unknown) as Array<{ id: string; email: string; role: string; can_manage_users: boolean }>;
    },
  });

  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"owner" | "admin" | "staff">("staff");
  const [canManage, setCanManage] = useState(false);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    await qc.invalidateQueries({ queryKey: ["profiles"] });
    await qc.invalidateQueries({ queryKey: ["pending_crew"] });
  }

  async function submitInvite(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      // queue in pending_crew as fallback (works even if email isn't sent)
      await supabase
        .from("pending_crew" as any)
        .upsert({ email: email.trim().toLowerCase(), role, can_manage_users: canManage }, { onConflict: "email" });
      await invite({ data: { email: email.trim().toLowerCase(), role, can_manage_users: canManage } });
      toast.success("User invited");
      setEmail("");
      refresh();
    } catch (err: any) {
      toast.error(err.message ?? "Invite failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl">Crew Members</h2>
        <p className="text-sm text-foreground/60">Invite teammates, assign roles, control permissions.</p>
      </div>

      <form onSubmit={submitInvite} className="rounded-2xl frost border border-white/10 p-4 space-y-3">
        <div className="flex items-center gap-2">
          <UserPlus className="h-4 w-4 text-[var(--gold)]" />
          <h3 className="font-display text-lg">Invite teammate</h3>
        </div>
        <div className="grid gap-3 md:grid-cols-[1fr_140px_160px_auto]">
          <Input type="email" required value={email} placeholder="email@nestburger.com" onChange={(e) => setEmail(e.target.value)} />
          <select value={role} onChange={(e) => setRole(e.target.value as any)} className="rounded-md bg-black/30 border border-white/10 px-3 text-sm">
            <option value="staff">Staff</option>
            <option value="admin">Admin</option>
            <option value="owner">Owner</option>
          </select>
          <label className="inline-flex items-center gap-2 text-sm">
            <input type="checkbox" checked={canManage} onChange={(e) => setCanManage(e.target.checked)} />
            Can manage users
          </label>
          <Button type="submit" disabled={busy} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Invite"}
          </Button>
        </div>
        <p className="text-xs text-foreground/50">If the user has never signed in, they'll auto-receive the role on first sign-up.</p>
      </form>

      {isLoading ? <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" /> : (
        <div className="space-y-2">
          {profiles?.map((p) => (
            <ProfileRow
              key={p.id}
              p={p}
              self={p.id === currentUserId}
              onSave={async (role, canManage) => {
                try { await update({ data: { id: p.id, role: role as any, can_manage_users: canManage } }); toast.success("Updated"); refresh(); }
                catch (e: any) { toast.error(e.message); }
              }}
              onRemove={async () => {
                if (!confirm(`Remove ${p.email}? This deletes their auth account.`)) return;
                try { await remove({ data: { id: p.id } }); toast.success("Removed"); refresh(); }
                catch (e: any) { toast.error(e.message); }
              }}
            />
          ))}
        </div>
      )}

      {pending && pending.length > 0 && (
        <div className="space-y-2">
          <h3 className="font-display text-lg flex items-center gap-2"><Mail className="h-4 w-4 text-[var(--gold)]" /> Pending invites</h3>
          {pending.map((p) => (
            <div key={p.id} className="rounded-xl border border-white/10 p-3 flex items-center justify-between">
              <div className="text-sm">
                <div>{p.email}</div>
                <div className="text-xs text-foreground/50">Will become <span className="text-[var(--gold)]">{p.role}</span> on first sign-in</div>
              </div>
              <Button variant="ghost" size="icon" onClick={async () => {
                await supabase.from("pending_crew" as any).delete().eq("id", p.id);
                refresh();
              }}><Trash2 className="h-4 w-4 text-red-400" /></Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProfileRow({
  p, self, onSave, onRemove,
}: {
  p: Profile; self: boolean;
  onSave: (role: string, canManage: boolean) => void;
  onRemove: () => void;
}) {
  const [role, setRole] = useState(p.role);
  const [canManage, setCanManage] = useState(p.can_manage_users);
  const dirty = role !== p.role || canManage !== p.can_manage_users;

  return (
    <div className="rounded-2xl frost border border-white/10 p-3 flex flex-wrap items-center gap-3">
      <div className="grid h-9 w-9 place-items-center rounded-full bg-[var(--gold)]/15 text-[var(--gold)]">
        {p.role === "owner" ? <Crown className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
      </div>
      <div className="flex-1 min-w-[200px]">
        <div className="text-sm">{p.email} {self && <span className="text-xs text-[var(--gold)]">(you)</span>}</div>
        {p.full_name && <div className="text-xs text-foreground/50">{p.full_name}</div>}
      </div>
      <select value={role} onChange={(e) => setRole(e.target.value)} disabled={self} className="rounded-md bg-black/30 border border-white/10 px-2 py-1 text-sm">
        <option value="staff">Staff</option>
        <option value="admin">Admin</option>
        <option value="owner">Owner</option>
      </select>
      <label className="inline-flex items-center gap-2 text-xs">
        <input type="checkbox" checked={canManage} onChange={(e) => setCanManage(e.target.checked)} disabled={self} />
        Manage users
      </label>
      {dirty && <Button size="sm" onClick={() => onSave(role, canManage)} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">Save</Button>}
      {!self && <Button variant="ghost" size="icon" onClick={onRemove}><Trash2 className="h-4 w-4 text-red-400" /></Button>}
    </div>
  );
}
