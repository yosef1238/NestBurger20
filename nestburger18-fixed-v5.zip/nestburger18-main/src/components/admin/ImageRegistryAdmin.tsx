import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ImagePlus, Loader2, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { uploadMedia } from "@/lib/cms";
import type { ImageRow } from "@/lib/cms";

export function ImageRegistryAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["image_registry", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("image_registry" as any)
        .select("*")
        .order("location_key");
      if (error) throw error;
      return ((data ?? []) as unknown) as ImageRow[];
    },
  });

  const [newKey, setNewKey] = useState("");
  async function refresh() {
    await qc.invalidateQueries({ queryKey: ["image_registry"] });
  }

  async function addKey() {
    if (!newKey.trim()) return;
    const { error } = await supabase
      .from("image_registry" as any)
      .insert({ location_key: newKey.trim(), url: "", description: "" });
    if (error) return toast.error(error.message);
    setNewKey("");
    refresh();
  }

  async function removeRow(id: string) {
    if (!confirm("Delete this image entry?")) return;
    const { error } = await supabase.from("image_registry" as any).delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  }

  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" />;

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display text-2xl">Global Image Editor</h2>
        <p className="text-sm text-foreground/60">
          Every image on the public site lives here. Click any tile to upload a replacement — changes appear on the site instantly.
        </p>
      </div>
      <div className="flex gap-2 max-w-md">
        <Input
          value={newKey}
          placeholder="new location_key (e.g. homepage.hero.background)"
          onChange={(e) => setNewKey(e.target.value)}
        />
        <Button onClick={addKey} variant="outline"><Plus className="h-4 w-4 mr-1" /> Add</Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {data?.map((row) => (
          <ImageTile key={row.id} row={row} onChange={refresh} onDelete={() => removeRow(row.id)} />
        ))}
      </div>
    </div>
  );
}

function ImageTile({ row, onChange, onDelete }: { row: ImageRow; onChange: () => void; onDelete: () => void }) {
  const [uploading, setUploading] = useState(false);
  const [alt, setAlt] = useState(row.alt);
  const [desc, setDesc] = useState(row.description);

  async function upload(file: File) {
    setUploading(true);
    try {
      const url = await uploadMedia(file, `registry/${row.location_key}`);
      const { error } = await (supabase.from("image_registry" as any) as any).update({ url }).eq("id", row.id);
      if (error) throw error;
      toast.success(`Updated ${row.location_key}`);
      onChange();
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }
  async function saveMeta() {
    const { error } = await (supabase.from("image_registry" as any) as any)
      .update({ alt, description: desc })
      .eq("id", row.id);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    onChange();
  }

  return (
    <div className="rounded-2xl frost border border-white/10 p-3 space-y-2">
      <label className="relative grid h-40 w-full place-items-center rounded-xl bg-black/40 border border-white/10 overflow-hidden cursor-pointer hover:border-[var(--gold)]/40">
        {row.url ? (
          <img src={row.url} alt={row.alt} className="h-full w-full object-cover" />
        ) : (
          <div className="grid place-items-center text-foreground/40 gap-1">
            <ImagePlus className="h-7 w-7" />
            <span className="text-xs">Upload image</span>
          </div>
        )}
        {uploading && <div className="absolute inset-0 grid place-items-center bg-black/60"><Loader2 className="h-5 w-5 animate-spin" /></div>}
        <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); }} />
      </label>
      <div className="text-[11px] font-mono text-[var(--gold)] break-all">{row.location_key}</div>
      <Input value={alt} placeholder="Alt text" onChange={(e) => setAlt(e.target.value)} className="h-8 text-xs" />
      <Input value={desc} placeholder="Description (where this image is used)" onChange={(e) => setDesc(e.target.value)} className="h-8 text-xs" />
      <div className="flex gap-2">
        <Button size="sm" variant="outline" onClick={saveMeta} className="flex-1">Save meta</Button>
        <Button size="sm" variant="ghost" onClick={onDelete}><Trash2 className="h-3.5 w-3.5 text-red-400" /></Button>
      </div>
    </div>
  );
}
