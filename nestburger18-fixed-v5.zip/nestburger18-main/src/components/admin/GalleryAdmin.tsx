import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronUp, Eye, EyeOff, ImagePlus, Loader2, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { uploadMedia } from "@/lib/cms";
import type { GalleryRow } from "@/lib/cms";

const SECTION_PRESETS = ["homepage.hero_slider", "homepage.gallery", "heavy_hitters.slider", "menu.banner"];

export function GalleryAdmin() {
  const [section, setSection] = useState(SECTION_PRESETS[0]);
  const [customSection, setCustomSection] = useState("");
  const activeSection = customSection.trim() || section;

  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["gallery_images", "admin", activeSection],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("gallery_images" as any)
        .select("*")
        .eq("section", activeSection)
        .order("order_index");
      if (error) throw error;
      return ((data ?? []) as unknown) as GalleryRow[];
    },
  });

  async function refresh() {
    await qc.invalidateQueries({ queryKey: ["gallery_images"] });
  }

  async function addImage(file: File) {
    try {
      const url = await uploadMedia(file, `gallery/${activeSection}`);
      const order = (data?.length ?? 0) + 1;
      const { error } = await supabase
        .from("gallery_images" as any)
        .insert({ section: activeSection, image_url: url, order_index: order, visible: true });
      if (error) throw error;
      toast.success("Added image");
      refresh();
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this image?")) return;
    const { error } = await supabase.from("gallery_images" as any).delete().eq("id", id);
    if (error) return toast.error(error.message);
    refresh();
  }

  async function toggleVisible(row: GalleryRow) {
    const { error } = await (supabase.from("gallery_images" as any) as any)
      .update({ visible: !row.visible })
      .eq("id", row.id);
    if (error) return toast.error(error.message);
    refresh();
  }

  async function move(row: GalleryRow, dir: -1 | 1) {
    const { error } = await (supabase.from("gallery_images" as any) as any)
      .update({ order_index: row.order_index + dir })
      .eq("id", row.id);
    if (error) return toast.error(error.message);
    refresh();
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display text-2xl">Image Sliders</h2>
        <p className="text-sm text-foreground/60">Manage the images that appear in each slider section.</p>
      </div>
      <div className="flex flex-wrap gap-2 items-center">
        {SECTION_PRESETS.map((s) => (
          <button
            key={s}
            onClick={() => { setSection(s); setCustomSection(""); }}
            className={`text-xs font-mono px-3 py-1.5 rounded-full border transition ${activeSection === s ? "border-[var(--gold)] bg-[var(--gold)]/15 text-[var(--gold)]" : "border-white/10 text-foreground/70"}`}
          >
            {s}
          </button>
        ))}
        <Input
          value={customSection}
          placeholder="or custom section key"
          onChange={(e) => setCustomSection(e.target.value)}
          className="max-w-xs h-8 text-xs font-mono"
        />
      </div>

      <label className="grid place-items-center rounded-2xl border-2 border-dashed border-white/15 p-8 cursor-pointer hover:border-[var(--gold)]/40">
        <Plus className="h-6 w-6 text-foreground/40 mb-1" />
        <span className="text-sm text-foreground/60">Upload image to <span className="font-mono text-[var(--gold)]">{activeSection}</span></span>
        <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) addImage(f); }} />
      </label>

      {isLoading ? (
        <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {data?.map((row, i) => (
            <div key={row.id} className="rounded-2xl frost border border-white/10 overflow-hidden">
              <div className="aspect-square bg-black/40">
                {row.image_url ? <img src={row.image_url} alt={row.alt} className="h-full w-full object-cover" /> : <ImagePlus className="h-5 w-5 m-4 text-foreground/40" />}
              </div>
              <div className="p-2 flex justify-between items-center">
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7" disabled={i === 0} onClick={() => move(row, -1)}><ChevronUp className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" disabled={i === (data.length - 1)} onClick={() => move(row, 1)}><ChevronDown className="h-3.5 w-3.5" /></Button>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleVisible(row)}>{row.visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5 text-foreground/40" />}</Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => remove(row.id)}><Trash2 className="h-3.5 w-3.5 text-red-400" /></Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
