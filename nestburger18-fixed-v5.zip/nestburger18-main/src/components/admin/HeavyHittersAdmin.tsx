import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronUp, Eye, EyeOff, ImagePlus, Loader2, Plus, Save, Trash2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { uploadMedia } from "@/lib/cms";

type Row = {
  id: string;
  title: string;
  description: string;
  price: string;
  image_url: string | null;
  order_index: number;
  visible: boolean;
};

export function HeavyHittersAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["heavy_hitters", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("heavy_hitters" as any)
        .select("*")
        .order("order_index");
      if (error) throw error;
      return ((data ?? []) as unknown) as Row[];
    },
  });

  async function refresh() {
    await qc.invalidateQueries({ queryKey: ["heavy_hitters"] });
  }

  async function add() {
    const order = (data?.length ?? 0) + 1;
    const { error } = await supabase
      .from("heavy_hitters" as any)
      .insert({ title: "New heavy hitter", description: "", price: "", order_index: order, visible: true });
    if (error) return toast.error(error.message);
    toast.success("Added");
    refresh();
  }

  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" />;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="font-display text-2xl">Heavy Hitters</h2>
          <p className="text-sm text-foreground/60">Top burgers shown on the homepage. 4+ items auto-converts into a slider.</p>
        </div>
        <Button onClick={add} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
          <Plus className="h-4 w-4 mr-1" /> Add
        </Button>
      </div>
      <div className="grid gap-3">
        {data?.map((row, i) => (
          <HeavyHitterCard key={row.id} row={row} index={i} total={data.length} onChange={refresh} />
        ))}
      </div>
    </div>
  );
}

function HeavyHitterCard({ row, index, total, onChange }: { row: Row; index: number; total: number; onChange: () => void }) {
  const [local, setLocal] = useState<Row>(row);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const dirty = JSON.stringify(local) !== JSON.stringify(row);

  useEffect(() => setLocal(row), [row.id]);

  async function save() {
    setSaving(true);
    const { id, ...patch } = local;
    const { error } = await (supabase.from("heavy_hitters" as any) as any).update(patch).eq("id", id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    onChange();
  }
  async function remove() {
    if (!confirm(`Delete "${row.title}"?`)) return;
    const { error } = await supabase.from("heavy_hitters" as any).delete().eq("id", row.id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    onChange();
  }
  async function toggleVisible() {
    const { error } = await (supabase.from("heavy_hitters" as any) as any).update({ visible: !row.visible }).eq("id", row.id);
    if (error) return toast.error(error.message);
    onChange();
  }
  async function move(dir: -1 | 1) {
    const newOrder = row.order_index + dir;
    const { error } = await (supabase.from("heavy_hitters" as any) as any).update({ order_index: newOrder }).eq("id", row.id);
    if (error) return toast.error(error.message);
    onChange();
  }
  async function upload(file: File) {
    setUploading(true);
    try {
      const url = await uploadMedia(file, "heavy_hitters");
      const { error } = await (supabase.from("heavy_hitters" as any) as any).update({ image_url: url }).eq("id", row.id);
      if (error) throw error;
      toast.success("Photo uploaded");
      onChange();
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="rounded-2xl frost border border-white/10 p-4">
      <div className="flex flex-col md:flex-row gap-4">
        <label className="relative shrink-0 grid h-24 w-24 place-items-center rounded-xl bg-black/40 border border-white/10 overflow-hidden cursor-pointer hover:border-[var(--gold)]/40">
          {row.image_url ? (
            <img src={row.image_url} alt="" className="h-full w-full object-cover" />
          ) : (
            <ImagePlus className="h-5 w-5 text-foreground/40" />
          )}
          {uploading && <div className="absolute inset-0 grid place-items-center bg-black/50"><Loader2 className="h-5 w-5 animate-spin" /></div>}
          <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); }} />
        </label>
        <div className="flex-1 grid gap-2 md:grid-cols-2">
          <Input value={local.title} placeholder="Title" onChange={(e) => setLocal({ ...local, title: e.target.value })} />
          <Input value={local.price} placeholder="Price" onChange={(e) => setLocal({ ...local, price: e.target.value })} />
          <Textarea value={local.description} placeholder="Description" className="md:col-span-2" rows={2} onChange={(e) => setLocal({ ...local, description: e.target.value })} />
        </div>
        <div className="flex md:flex-col gap-1 justify-end">
          <Button variant="ghost" size="icon" disabled={index === 0} onClick={() => move(-1)}><ChevronUp className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" disabled={index === total - 1} onClick={() => move(1)}><ChevronDown className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" onClick={toggleVisible}>{row.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4 text-foreground/40" />}</Button>
          <Button variant="ghost" size="icon" onClick={remove}><Trash2 className="h-4 w-4 text-red-400" /></Button>
        </div>
      </div>
      {dirty && (
        <div className="mt-3 flex justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={() => setLocal(row)}><X className="h-3 w-3 mr-1" /> Cancel</Button>
          <Button size="sm" onClick={save} disabled={saving} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="h-3 w-3 mr-1" /> Save</>}
          </Button>
        </div>
      )}
    </div>
  );
}
