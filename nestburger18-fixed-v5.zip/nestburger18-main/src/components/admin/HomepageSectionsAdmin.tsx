import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Save, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import type { SectionRow } from "@/lib/cms";

export function HomepageSectionsAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["homepage_sections", "admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("homepage_sections" as any)
        .select("*")
        .order("order_index");
      if (error) throw error;
      return ((data ?? []) as unknown) as SectionRow[];
    },
  });

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display text-2xl">Homepage Content</h2>
        <p className="text-sm text-foreground/60">Edit the text shown in each homepage section. Changes are live.</p>
      </div>
      {isLoading ? <Loader2 className="h-5 w-5 animate-spin text-[var(--gold)]" /> : (
        <div className="grid gap-4">
          {data?.map((row) => <SectionCard key={row.id} row={row} onSaved={() => qc.invalidateQueries({ queryKey: ["homepage_sections"] })} />)}
        </div>
      )}
    </div>
  );
}

function SectionCard({ row, onSaved }: { row: SectionRow; onSaved: () => void }) {
  const [local, setLocal] = useState(row);
  const [saving, setSaving] = useState(false);
  useEffect(() => setLocal(row), [row.id]);
  const dirty = JSON.stringify(local) !== JSON.stringify(row);

  async function save() {
    setSaving(true);
    const { id, ...patch } = local;
    const { error } = await (supabase.from("homepage_sections" as any) as any).update(patch).eq("id", id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    onSaved();
  }

  return (
    <div className="rounded-2xl frost border border-white/10 p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-xs font-mono text-[var(--gold)]">{row.section_key}</div>
        <Button variant="ghost" size="sm" onClick={async () => {
          const { error } = await (supabase.from("homepage_sections" as any) as any).update({ visible: !row.visible }).eq("id", row.id);
          if (error) return toast.error(error.message);
          onSaved();
        }}>{row.visible ? "Visible" : "Hidden"}</Button>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <div><Label className="text-xs">Title</Label><Input value={local.title} onChange={(e) => setLocal({ ...local, title: e.target.value })} /></div>
        <div><Label className="text-xs">Subtitle</Label><Input value={local.subtitle} onChange={(e) => setLocal({ ...local, subtitle: e.target.value })} /></div>
      </div>
      <div><Label className="text-xs">Body</Label><Textarea rows={3} value={local.body} onChange={(e) => setLocal({ ...local, body: e.target.value })} /></div>
      {dirty && (
        <div className="flex justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={() => setLocal(row)}><X className="h-3 w-3 mr-1" /> Cancel</Button>
          <Button size="sm" onClick={save} disabled={saving} className="bg-[var(--gold)] text-[var(--primary-foreground)] hover:bg-[var(--gold)]/90">
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <><Save className="h-3 w-3 mr-1" /> Save</>}
          </Button>
        </div>
      )}
    </div>
  );
}
