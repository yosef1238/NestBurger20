-- ============================================================
-- [NB-016] OWNER BOOTSTRAP FIX + DIAGNOSTIC HELPER
-- ============================================================
--
-- Context: yoom15422@gmail.com signed up BEFORE the migration that creates
-- handle_new_crew_user() ran. That trigger only fires on NEW auth.users
-- inserts (AFTER INSERT), so existing accounts never got processed —
-- the pending_crew row for this email was queued but never consumed.
--
-- This migration is idempotent: safe to re-run, only acts if the owner
-- role is actually missing.
-- ============================================================

DO $$
DECLARE
  target_uid uuid;
  already_owner boolean;
BEGIN
  -- Find the auth user for this email
  SELECT id INTO target_uid FROM auth.users WHERE lower(email) = lower('yoom15422@gmail.com') LIMIT 1;

  IF target_uid IS NULL THEN
    RAISE NOTICE '[NB-016] No auth.users row found for yoom15422@gmail.com — account may not exist yet.';
  ELSE
    SELECT EXISTS (
      SELECT 1 FROM public.user_roles WHERE user_id = target_uid AND role::text = 'owner'
    ) INTO already_owner;

    IF already_owner THEN
      RAISE NOTICE '[NB-016] User % is already an owner. No action taken.', target_uid;
    ELSE
      -- Grant owner role (idempotent via ON CONFLICT)
      INSERT INTO public.user_roles (user_id, role)
      VALUES (target_uid, 'owner'::public.app_role)
      ON CONFLICT (user_id, role) DO NOTHING;

      -- Ensure profiles row reflects owner + can_manage_users
      INSERT INTO public.profiles (id, email, role, can_manage_users)
      VALUES (target_uid, 'yoom15422@gmail.com', 'owner', true)
      ON CONFLICT (id) DO UPDATE SET role = 'owner', can_manage_users = true;

      -- Clean up the stale pending_crew row so it doesn't re-trigger confusion
      DELETE FROM public.pending_crew WHERE lower(email) = lower('yoom15422@gmail.com');

      RAISE NOTICE '[NB-016] Owner role granted to %.', target_uid;
    END IF;
  END IF;
END $$;


-- ============================================================
-- [NB-017] Diagnostic function — call this from SQL editor any time to
-- check exactly why a given email isn't getting crew access.
-- Usage: SELECT * FROM public.diagnose_crew_access('someone@email.com');
-- ============================================================

CREATE OR REPLACE FUNCTION public.diagnose_crew_access(_email text)
RETURNS TABLE (
  check_name text,
  result text,
  detail text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid;
BEGIN
  SELECT id INTO uid FROM auth.users WHERE lower(email) = lower(_email) LIMIT 1;

  IF uid IS NULL THEN
    RETURN QUERY SELECT '[NB-017-A] auth.users'::text, 'MISSING'::text,
      'No account exists for this email. User must sign up first.'::text;
    RETURN;
  END IF;

  RETURN QUERY SELECT '[NB-017-A] auth.users'::text, 'OK'::text, uid::text;

  RETURN QUERY
    SELECT '[NB-017-B] user_roles'::text,
      CASE WHEN EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = uid) THEN 'OK' ELSE 'MISSING' END,
      COALESCE((SELECT string_agg(role::text, ', ') FROM public.user_roles WHERE user_id = uid), 'no rows — this is why /nest-crew shows isAdmin=false');

  RETURN QUERY
    SELECT '[NB-017-C] profiles'::text,
      CASE WHEN EXISTS (SELECT 1 FROM public.profiles WHERE id = uid) THEN 'OK' ELSE 'MISSING' END,
      COALESCE((SELECT 'role=' || role || ', can_manage_users=' || can_manage_users::text FROM public.profiles WHERE id = uid), 'no profile row');

  RETURN QUERY
    SELECT '[NB-017-D] pending_crew'::text,
      CASE WHEN EXISTS (SELECT 1 FROM public.pending_crew WHERE lower(email) = lower(_email)) THEN 'STUCK' ELSE 'CLEAR' END,
      COALESCE((SELECT 'role=' || role || ' — queued but never consumed, the auth trigger only fires on NEW signups' FROM public.pending_crew WHERE lower(email) = lower(_email)), 'no stuck invite');
END;
$$;

REVOKE EXECUTE ON FUNCTION public.diagnose_crew_access(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.diagnose_crew_access(text) TO service_role;
-- Note: run this from the Supabase SQL Editor (runs as postgres/service role), not from the app.
