-- ============================================================
-- SECURITY FIX 2: Additional vulnerabilities discovered in audit
-- ============================================================


-- ============================================================
-- FIX 5 (Critical): Any authenticated user can escalate their
-- own role by updating the `profiles` table directly.
--
-- Root cause: "profiles_self_update" policy allows any user to
-- UPDATE their own row with no column restriction. This means
-- they can set role='admin' and can_manage_users=true on
-- themselves, bypassing user_roles protections entirely.
-- The admin panel reads role from profiles, so this is a full
-- privilege escalation path.
--
-- Fix: Replace the open self-update policy with one that
-- explicitly blocks changes to role and can_manage_users.
-- Those columns are now write-protected at the DB level and
-- can only be changed by the service_role (server functions).
-- ============================================================

DROP POLICY IF EXISTS "profiles_self_update" ON public.profiles;

-- Users may only update their own display name and avatar.
-- role and can_manage_users are immutable from the client side.
CREATE POLICY "profiles_self_update_safe" ON public.profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (
    id = auth.uid()
    -- Prevent clients from changing privileged columns
    AND role = (SELECT role FROM public.profiles WHERE id = auth.uid())
    AND can_manage_users = (SELECT can_manage_users FROM public.profiles WHERE id = auth.uid())
  );


-- ============================================================
-- FIX 6 (Medium): menu_items and trending_items write policies
-- check for 'admin' role only, locking out 'owner' role users.
--
-- Root cause: Original policies use has_role(uid, 'admin') but
-- the 'owner' role is a superset of admin — owners should be
-- able to manage all content. As-is, owners get a silent 403
-- when trying to edit menu or trending items.
--
-- Fix: Update write policies to allow both owner and admin.
-- ============================================================

DROP POLICY IF EXISTS "menu_items admin write" ON public.menu_items;
DROP POLICY IF EXISTS "trending_items admin write" ON public.trending_items;

CREATE POLICY "menu_items crew write" ON public.menu_items
  FOR ALL TO authenticated
  USING  (public.is_crew(auth.uid()))
  WITH CHECK (public.is_crew(auth.uid()));

CREATE POLICY "trending_items crew write" ON public.trending_items
  FOR ALL TO authenticated
  USING  (public.is_crew(auth.uid()))
  WITH CHECK (public.is_crew(auth.uid()));


-- ============================================================
-- FIX 7 (Medium): All crew members (including staff) can read
-- all profiles, exposing every teammate's email address.
--
-- Root cause: "profiles_self_read" uses is_crew() which
-- includes staff. Staff should only see their own profile.
-- Only admin/owner should be able to list all crew members.
--
-- Fix: Restrict broad reads to admin/owner only. Staff see
-- only themselves (their own row is always included).
-- ============================================================

DROP POLICY IF EXISTS "profiles_self_read" ON public.profiles;

CREATE POLICY "profiles_read" ON public.profiles
  FOR SELECT TO authenticated
  USING (
    id = auth.uid()                          -- always see own profile
    OR public.crew_can_delete(auth.uid())    -- admin/owner can see everyone
  );


-- ============================================================
-- FIX 8 (Medium): site_settings write is not restricted to
-- admin/owner — any crew member (staff) can update hero_pills,
-- WhatsApp number, and social links via the admin panel.
--
-- Root cause: "site_settings admin write" policy uses
-- has_role(uid,'admin') which (a) misses 'owner' and
-- (b) the admin panel lets any isAdmin user reach LinksAdmin
-- and PillsAdmin tabs regardless of role.
--
-- Fix: Restrict site_settings writes to owner/admin only.
-- ============================================================

DROP POLICY IF EXISTS "site_settings admin write" ON public.site_settings;

CREATE POLICY "site_settings admin write" ON public.site_settings
  FOR ALL TO authenticated
  USING  (public.crew_can_delete(auth.uid()))
  WITH CHECK (public.crew_can_delete(auth.uid()));
