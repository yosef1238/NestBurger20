-- ============================================================
-- SECURITY FIX: Resolve all 4 reported vulnerabilities
-- ============================================================

-- ============================================================
-- FIX 1 (Critical): Staff-level crew members can upload,
-- update, and delete files in the nest-media bucket.
--
-- Root cause: nest_media_crew_update and nest_media_crew_delete
-- use is_crew() which includes 'staff'. Only owner/admin should
-- be allowed to mutate (update/delete) storage objects.
-- Staff may only INSERT (upload new files), not overwrite or
-- delete existing ones.
-- ============================================================

DROP POLICY IF EXISTS "nest_media_crew_update" ON storage.objects;
DROP POLICY IF EXISTS "nest_media_crew_delete" ON storage.objects;

-- Staff can upload new files but NOT update or delete existing ones.
-- Update and delete are restricted to owner/admin only.
CREATE POLICY "nest_media_admin_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING  (bucket_id = 'nest-media' AND public.crew_can_delete(auth.uid()))
  WITH CHECK (bucket_id = 'nest-media' AND public.crew_can_delete(auth.uid()));

CREATE POLICY "nest_media_admin_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'nest-media' AND public.crew_can_delete(auth.uid()));


-- ============================================================
-- FIX 2 (Critical): Any authenticated user can escalate their
-- own role to admin.
--
-- Root cause: The user_roles table has no INSERT/UPDATE RLS
-- policy, so authenticated users can write any row including
-- granting themselves admin. We lock the table down: only the
-- service_role (used by server functions) may write to it.
-- The claimFirstAdmin server function already uses supabaseAdmin
-- (service_role), so legitimate flows are unaffected.
-- ============================================================

-- Remove any existing permissive write policies on user_roles
DROP POLICY IF EXISTS "users insert own roles" ON public.user_roles;
DROP POLICY IF EXISTS "users update own roles" ON public.user_roles;
DROP POLICY IF EXISTS "users delete own roles" ON public.user_roles;

-- Revoke all write privileges from authenticated users on user_roles.
-- Reads are still allowed (existing "users see own roles" SELECT policy).
-- All writes go through supabaseAdmin (service_role) in server functions.
REVOKE INSERT, UPDATE, DELETE ON public.user_roles FROM authenticated;
GRANT  INSERT, UPDATE, DELETE ON public.user_roles TO service_role;


-- ============================================================
-- FIX 3 (Warning): Owner's personal WhatsApp number is
-- publicly readable.
--
-- Root cause: site_settings SELECT policy allows anon and
-- authenticated to read all columns including whatsapp_number.
-- Fix: restrict the public-facing query to only the columns
-- needed by the frontend (hero_pills, instagram_url,
-- facebook_url). whatsapp_number is kept readable only for
-- authenticated crew users (needed by the admin panel).
-- ============================================================

-- Drop the overly permissive read policy
DROP POLICY IF EXISTS "site_settings read all" ON public.site_settings;

-- Anon / public visitors only need hero_pills and social URLs.
-- We achieve column-level restriction via a security-barrier view.
CREATE OR REPLACE VIEW public.site_settings_public
  WITH (security_barrier = true)
AS
  SELECT
    id,
    instagram_url,
    facebook_url,
    hero_pills
  FROM public.site_settings;

GRANT SELECT ON public.site_settings_public TO anon, authenticated;

-- Authenticated crew users still get full access for the admin panel.
CREATE POLICY "site_settings authenticated read" ON public.site_settings
  FOR SELECT TO authenticated
  USING (true);

-- Keep anon restricted to the view only (no direct table access).
-- anon has no SELECT on the base table now (policy above is TO authenticated).
-- site_settings_public view is their read path.


-- ============================================================
-- FIX 4 (Warning): Signed-In Users Can Execute SECURITY
-- DEFINER Functions.
--
-- Root cause: touch_updated_at() is a SECURITY DEFINER trigger
-- function but PUBLIC still has EXECUTE on it, meaning any
-- authenticated user can call it directly to tamper with
-- updated_at values.
-- ============================================================

REVOKE EXECUTE ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;
GRANT  EXECUTE ON FUNCTION public.touch_updated_at() TO service_role;
