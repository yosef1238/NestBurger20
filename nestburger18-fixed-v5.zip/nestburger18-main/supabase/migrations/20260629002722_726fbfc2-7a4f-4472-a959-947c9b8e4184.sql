
-- 1. Enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'staff';

-- 2. Helper functions
CREATE OR REPLACE FUNCTION public.is_crew(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _uid AND role::text IN ('owner','admin','staff'))
$$;
CREATE OR REPLACE FUNCTION public.is_owner(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _uid AND role::text = 'owner')
$$;
CREATE OR REPLACE FUNCTION public.crew_can_delete(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _uid AND role::text IN ('owner','admin'))
$$;

-- 3. profiles
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'staff',
  can_manage_users boolean NOT NULL DEFAULT false,
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_self_read" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.is_crew(auth.uid()));
CREATE POLICY "profiles_self_update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_owner_all" ON public.profiles FOR ALL TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));
CREATE TRIGGER profiles_touch_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 4. pending_crew
CREATE TABLE IF NOT EXISTS public.pending_crew (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  role text NOT NULL DEFAULT 'staff',
  can_manage_users boolean NOT NULL DEFAULT false,
  invited_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pending_crew TO authenticated;
GRANT ALL ON public.pending_crew TO service_role;
ALTER TABLE public.pending_crew ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pending_crew_owner_all" ON public.pending_crew FOR ALL TO authenticated USING (public.is_owner(auth.uid())) WITH CHECK (public.is_owner(auth.uid()));

-- 5. New-user trigger
CREATE OR REPLACE FUNCTION public.handle_new_crew_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  pending RECORD;
  assigned_role text;
  manage_flag boolean;
BEGIN
  SELECT * INTO pending FROM public.pending_crew WHERE lower(email) = lower(NEW.email) LIMIT 1;
  IF pending.id IS NOT NULL THEN
    assigned_role := pending.role;
    manage_flag := pending.can_manage_users;
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, pending.role::public.app_role) ON CONFLICT (user_id, role) DO NOTHING;
    DELETE FROM public.pending_crew WHERE id = pending.id;
  ELSE
    assigned_role := 'staff';
    manage_flag := false;
  END IF;
  INSERT INTO public.profiles (id, email, role, can_manage_users)
  VALUES (NEW.id, NEW.email, assigned_role, manage_flag)
  ON CONFLICT (id) DO UPDATE SET email = EXCLUDED.email, role = EXCLUDED.role, can_manage_users = EXCLUDED.can_manage_users;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS on_auth_user_created_crew ON auth.users;
CREATE TRIGGER on_auth_user_created_crew AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_crew_user();

-- Backfill profiles
INSERT INTO public.profiles (id, email, role, can_manage_users)
SELECT u.id, u.email,
  COALESCE((SELECT role::text FROM public.user_roles WHERE user_id = u.id LIMIT 1), 'staff'),
  false
FROM auth.users u
ON CONFLICT (id) DO NOTHING;

-- 6. heavy_hitters
CREATE TABLE IF NOT EXISTS public.heavy_hitters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  price text NOT NULL DEFAULT '',
  image_url text,
  order_index integer NOT NULL DEFAULT 0,
  visible boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.heavy_hitters TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.heavy_hitters TO authenticated;
GRANT ALL ON public.heavy_hitters TO service_role;
ALTER TABLE public.heavy_hitters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "hh_read" ON public.heavy_hitters FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "hh_ins" ON public.heavy_hitters FOR INSERT TO authenticated WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "hh_upd" ON public.heavy_hitters FOR UPDATE TO authenticated USING (public.is_crew(auth.uid())) WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "hh_del" ON public.heavy_hitters FOR DELETE TO authenticated USING (public.crew_can_delete(auth.uid()));
CREATE TRIGGER heavy_hitters_touch BEFORE UPDATE ON public.heavy_hitters FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 7. image_registry
CREATE TABLE IF NOT EXISTS public.image_registry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_key text NOT NULL UNIQUE,
  url text NOT NULL DEFAULT '',
  alt text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.image_registry TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.image_registry TO authenticated;
GRANT ALL ON public.image_registry TO service_role;
ALTER TABLE public.image_registry ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ir_read" ON public.image_registry FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "ir_ins" ON public.image_registry FOR INSERT TO authenticated WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "ir_upd" ON public.image_registry FOR UPDATE TO authenticated USING (public.is_crew(auth.uid())) WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "ir_del" ON public.image_registry FOR DELETE TO authenticated USING (public.crew_can_delete(auth.uid()));
CREATE TRIGGER image_registry_touch BEFORE UPDATE ON public.image_registry FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 8. gallery_images
CREATE TABLE IF NOT EXISTS public.gallery_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section text NOT NULL,
  image_url text NOT NULL,
  alt text NOT NULL DEFAULT '',
  caption text NOT NULL DEFAULT '',
  order_index integer NOT NULL DEFAULT 0,
  visible boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS gallery_images_section_idx ON public.gallery_images(section, order_index);
GRANT SELECT ON public.gallery_images TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gallery_images TO authenticated;
GRANT ALL ON public.gallery_images TO service_role;
ALTER TABLE public.gallery_images ENABLE ROW LEVEL SECURITY;
CREATE POLICY "g_read" ON public.gallery_images FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "g_ins" ON public.gallery_images FOR INSERT TO authenticated WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "g_upd" ON public.gallery_images FOR UPDATE TO authenticated USING (public.is_crew(auth.uid())) WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "g_del" ON public.gallery_images FOR DELETE TO authenticated USING (public.crew_can_delete(auth.uid()));
CREATE TRIGGER gallery_touch BEFORE UPDATE ON public.gallery_images FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 9. homepage_sections
CREATE TABLE IF NOT EXISTS public.homepage_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_key text NOT NULL UNIQUE,
  title text NOT NULL DEFAULT '',
  subtitle text NOT NULL DEFAULT '',
  body text NOT NULL DEFAULT '',
  extra jsonb NOT NULL DEFAULT '{}'::jsonb,
  visible boolean NOT NULL DEFAULT true,
  order_index integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.homepage_sections TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.homepage_sections TO authenticated;
GRANT ALL ON public.homepage_sections TO service_role;
ALTER TABLE public.homepage_sections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "h_read" ON public.homepage_sections FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "h_ins" ON public.homepage_sections FOR INSERT TO authenticated WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "h_upd" ON public.homepage_sections FOR UPDATE TO authenticated USING (public.is_crew(auth.uid())) WITH CHECK (public.is_crew(auth.uid()));
CREATE POLICY "h_del" ON public.homepage_sections FOR DELETE TO authenticated USING (public.crew_can_delete(auth.uid()));
CREATE TRIGGER homepage_touch BEFORE UPDATE ON public.homepage_sections FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- 10. Storage policies for nest-media
DROP POLICY IF EXISTS "nest_media_public_read" ON storage.objects;
DROP POLICY IF EXISTS "nest_media_crew_insert" ON storage.objects;
DROP POLICY IF EXISTS "nest_media_crew_update" ON storage.objects;
DROP POLICY IF EXISTS "nest_media_crew_delete" ON storage.objects;
CREATE POLICY "nest_media_public_read" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'nest-media');
CREATE POLICY "nest_media_crew_insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'nest-media' AND public.is_crew(auth.uid()));
CREATE POLICY "nest_media_crew_update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'nest-media' AND public.is_crew(auth.uid())) WITH CHECK (bucket_id = 'nest-media' AND public.is_crew(auth.uid()));
CREATE POLICY "nest_media_crew_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'nest-media' AND public.is_crew(auth.uid()));

-- 11. Realtime
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='heavy_hitters') THEN ALTER PUBLICATION supabase_realtime ADD TABLE public.heavy_hitters; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='image_registry') THEN ALTER PUBLICATION supabase_realtime ADD TABLE public.image_registry; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='gallery_images') THEN ALTER PUBLICATION supabase_realtime ADD TABLE public.gallery_images; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='homepage_sections') THEN ALTER PUBLICATION supabase_realtime ADD TABLE public.homepage_sections; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='menu_items') THEN ALTER PUBLICATION supabase_realtime ADD TABLE public.menu_items; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='trending_items') THEN ALTER PUBLICATION supabase_realtime ADD TABLE public.trending_items; END IF;
END $$;

-- 12. Seeds
INSERT INTO public.image_registry (location_key, description) VALUES
  ('homepage.hero.background', 'Hero section background image'),
  ('homepage.hero.logo', 'Main logo'),
  ('homepage.about.image', 'About section image'),
  ('homepage.contact.image', 'Contact section image'),
  ('homepage.footer.image', 'Footer accent image'),
  ('homepage.menu.background', 'Menu section background'),
  ('homepage.gallery.cover', 'Gallery cover image'),
  ('homepage.heavy_hitters.background', 'Heavy hitters section background'),
  ('homepage.trending.background', 'Trending section background')
ON CONFLICT (location_key) DO NOTHING;

INSERT INTO public.homepage_sections (section_key, title, subtitle, body, order_index) VALUES
  ('hero', 'NEST BURGER', 'Smashed to order', 'Fresh daily • Hand-crafted • Smashed to order', 1),
  ('about', 'About Us', 'The story behind the smash', 'We craft every burger with love, sourcing the freshest ingredients daily.', 2),
  ('heavy_hitters', 'Top Heavy Hitters', 'The crowd favorites', 'Our most loved burgers, served fresh every day.', 3),
  ('trending', 'Trending Now', 'What everyone is ordering', '', 4),
  ('contact', 'Visit Us', 'Come hang out', 'We can''t wait to feed you.', 5)
ON CONFLICT (section_key) DO NOTHING;

INSERT INTO public.heavy_hitters (title, description, price, order_index) VALUES
  ('Classic Smash', 'Double smashed patty, american cheese, pickles, nest sauce', '149 EGP', 1),
  ('Truffle Nest', 'Truffle mayo, caramelized onions, smashed beef, gruyère', '189 EGP', 2),
  ('Spicy Crown', 'Jalapeños, chipotle aioli, pepper jack, double smash', '169 EGP', 3)
ON CONFLICT DO NOTHING;

-- 13. Queue owner (text-only; promotion happens at next signup OR via the post-migration insert step)
INSERT INTO public.pending_crew (email, role, can_manage_users)
VALUES ('yoom15422@gmail.com', 'owner', true)
ON CONFLICT (email) DO UPDATE SET role = 'owner', can_manage_users = true;
