
-- Restrict has_role execution to fix linter warning
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO service_role;

-- Storage policies for nest-media bucket
CREATE POLICY "nest-media public read"
ON storage.objects FOR SELECT TO anon, authenticated
USING (bucket_id = 'nest-media');

CREATE POLICY "nest-media admin upload"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'nest-media' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "nest-media admin update"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'nest-media' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "nest-media admin delete"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'nest-media' AND public.has_role(auth.uid(), 'admin'));
